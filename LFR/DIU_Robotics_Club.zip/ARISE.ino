#include <Wire.h>
#include <EEPROM.h>
#include "SSD1306Ascii.h"
#include "SSD1306AsciiWire.h"

SSD1306AsciiWire oled;

/**************** PINS ****************/

#define BTN_UP     0
#define BTN_OK     1
#define BTN_DOWN   2

#define LED_PIN    13

#define LPWM       3
#define LFWD       4
#define LBWD       5

#define RFWD       6
#define RBWD       7
#define RPWM       11

/************* SENSOR PINS ************/

byte sensorPin[6] =
{
  A0, A1, A2, A3, A6, A7
};

/************* VARIABLES **************/

int sensorValue[6];
int sensorMin[6];
int sensorMax[6];
int sensorMid[6];

byte sensorDigital[6];

int menuIndex = 1;

bool inverseMode = false;
bool autoInverseEnabled = true;

/************* SPEED & PID ************/

float Kp = 24.0;
float Ki = 0.0;
float Kd = 20.0;

float error = 0;
float lastError = 0;
float integral = 0;

int baseSpeed = 175;
int maxSpeed  = 255;
int gapSpeed  = 160;
int turnSpeed = 190;

// Track timing variables for Gap, Inverse & Finish
unsigned long runStartTime   = 0;
unsigned long gapStartTime   = 0;
const unsigned long GAP_TIMEOUT = 380; // ms to shoot across dashed line
unsigned long floodStartTime = 0;
unsigned long lastFlipTime   = 0;

/****************************************/

void setup()
{
  // Fast ADC prescaler (16us conversion -> 6x faster than default Arduino)
  ADCSRA = (ADCSRA & 0xF8) | 0x05;

  Wire.begin();

  oled.begin(&Adafruit128x64, 0x3C);
  oled.setFont(Adafruit5x7);
  oled.clear();

  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_OK, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  pinMode(LFWD, OUTPUT);
  pinMode(LBWD, OUTPUT);

  pinMode(RFWD, OUTPUT);
  pinMode(RBWD, OUTPUT);

  pinMode(LPWM, OUTPUT);
  pinMode(RPWM, OUTPUT);

  stopMotor();

  splash();

  loadCalibration();
}

void loop()
{
  menuSystem();
}
