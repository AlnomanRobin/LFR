void splash()
{
 oled.clear();

 oled.set2X();

 oled.setCursor(30,2);
 oled.print("DIU");

 oled.set1X();

 oled.setCursor(18,6);
 oled.print("TRAXION LFR");

 delay(2000);
}

byte button(byte pin)
{
 if(!digitalRead(pin))
 {
   delay(20);

   while(!digitalRead(pin));

   return 1;
 }

 return 0;
}

void text(String t,int x,int y)
{
 oled.setCursor(x,y);
 oled.print(t);
}