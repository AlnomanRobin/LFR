bool circleDetected()
{
   byte sum=0;

   for(byte i=0;i<6;i++)
   {
      sum+=sensorDigital[i];
   }

   return (sum>=5);
}

void handleCircle()
{
   motor(180,180);

   delay(180);

   while(circleDetected())
   {
      calculatePID();
   }
}
