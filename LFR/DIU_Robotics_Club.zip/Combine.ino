/****************************************
         COMBINE MODE & MAZE FUNCTIONS
****************************************/

char path[128];
int pathIndex = 0;
char lastTurn = 'S';

bool crossJunction  = false;
bool leftJunction   = false;
bool rightJunction  = false;
bool straightPath   = false;
bool deadEnd        = false;
bool finishDetected = false;

void storePath(char dir)
{
  if(pathIndex < 128)
  {
    path[pathIndex++] = dir;
  }
}

void optimizePath()
{
  if(pathIndex < 3 || path[pathIndex - 2] != 'B')
  {
    return;
  }

  char turnBefore = path[pathIndex - 3];
  char turnAfter  = path[pathIndex - 1];
  char resolved   = ' ';

  // Standard Maze Reduction Rules (LSRB):
  if(turnBefore == 'L' && turnAfter == 'L') resolved = 'S';
  else if(turnBefore == 'L' && turnAfter == 'S') resolved = 'R';
  else if(turnBefore == 'R' && turnAfter == 'L') resolved = 'S';
  else if(turnBefore == 'S' && turnAfter == 'L') resolved = 'R';
  else if(turnBefore == 'S' && turnAfter == 'S') resolved = 'B';
  else if(turnBefore == 'L' && turnAfter == 'R') resolved = 'B';
  else if(turnBefore == 'R' && turnAfter == 'R') resolved = 'S';
  else if(turnBefore == 'S' && turnAfter == 'R') resolved = 'L';
  else if(turnBefore == 'R' && turnAfter == 'S') resolved = 'L';

  if(resolved != ' ')
  {
    path[pathIndex - 3] = resolved;
    pathIndex -= 2;
  }
}

void detectJunction()
{
  digitalSensor();

  crossJunction  = false;
  leftJunction   = false;
  rightJunction  = false;
  straightPath   = false;
  deadEnd        = false;
  finishDetected = false;

  byte sum = 0;
  for(byte i = 0; i < 6; i++)
  {
    sum += sensorDigital[i];
  }

  // Dead End (all sensors white, after gap timeout)
  if(sum == 0)
  {
    if(abs(lastError) < 2.0)
    {
      if(gapStartTime == 0) gapStartTime = millis();
      if(millis() - gapStartTime < GAP_TIMEOUT)
      {
        motor(gapSpeed, gapSpeed);
        return;
      }
    }
    deadEnd = true;
    return;
  }

  gapStartTime = 0;

  // Cross Junction or Finish Box
  if((sensorDigital[0] && sensorDigital[5]) || sum >= 5)
  {
    if(confirmNode())
    {
      motor(140, 140);
      delay(50);
      digitalSensor();
      byte postSum = 0;
      for(byte i = 0; i < 6; i++) postSum += sensorDigital[i];

      if(postSum >= 5)
      {
        finishDetected = true;
      }
      else
      {
        crossJunction = true;
      }
      return;
    }
  }

  // Left branch (far-left S0 active)
  if(sensorDigital[0])
  {
    leftJunction = true;
    if(sensorDigital[2] || sensorDigital[3]) straightPath = true;
    return;
  }

  // Right branch (far-right S5 active)
  if(sensorDigital[5])
  {
    rightJunction = true;
    if(sensorDigital[2] || sensorDigital[3]) straightPath = true;
    return;
  }

  // Normal line follow
  if(sensorDigital[2] || sensorDigital[3])
  {
    straightPath = true;
  }
}

//-------------------------------------

void turnLeft()
{
  brakeMotor();

  motor(-190, 190);

  delay(140);

  while(!sensorDigital[2] && !sensorDigital[3])
  {
    digitalSensor();
  }

  stopMotor();

  storePath('L');
}

//-------------------------------------

void turnRight()
{
  brakeMotor();

  motor(190, -190);

  delay(140);

  while(!sensorDigital[2] && !sensorDigital[3])
  {
    digitalSensor();
  }

  stopMotor();

  storePath('R');
}

//-------------------------------------

void goStraight()
{
  motor(180, 180);

  delay(100);

  storePath('S');
}

//-------------------------------------

void uTurn()
{
  safeUTurn();
}

//-------------------------------------

void runShortestPath()
{
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("SPRINT PHASE");
  oled.setCursor(0, 2);
  oled.print("Path: ");
  for(int i = 0; i < pathIndex; i++)
  {
    oled.print(path[i]);
  }
  oled.setCursor(0, 6);
  oled.print("[Press OK to Run]");

  while(!button(BTN_OK));
  delay(300);

  int step = 0;
  while(!button(BTN_OK) && step < pathIndex)
  {
    detectJunction();

    if(finishDetected)
    {
      brakeMotor();
      oled.clear();
      oled.setCursor(20, 3);
      oled.print("WINNER!");
      delay(2000);
      return;
    }

    if(crossJunction || leftJunction || rightJunction)
    {
      char act = path[step++];
      if(act == 'L') turnLeft();
      else if(act == 'R') turnRight();
      else if(act == 'S') goStraight();
    }
    else
    {
      calculatePID();
    }
  }

  stopMotor();
}

//-------------------------------------

void leftPriorityMode()
{
  runStartTime = millis();
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("RUN: LEFT PRIORITY");
  oled.setCursor(0, 6);
  oled.print("[OK: Stop]");

  while(!button(BTN_OK))
  {
    detectJunction();

    if(finishDetected)
    {
      brakeMotor();
      oled.clear();
      oled.setCursor(15, 3);
      oled.print("FINISH REACHED!");
      delay(2000);
      break;
    }
    else if(crossJunction || leftJunction)
    {
      turnLeft();
    }
    else if(rightJunction)
    {
      if(straightPath)
      {
        goStraight();
      }
      else
      {
        turnRight();
      }
    }
    else if(deadEnd)
    {
      uTurn();
    }
    else
    {
      calculatePID();
    }
  }

  stopMotor();
}

//-------------------------------------

void rightPriorityMode()
{
  runStartTime = millis();
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("RUN: RIGHT PRIORITY");
  oled.setCursor(0, 6);
  oled.print("[OK: Stop]");

  while(!button(BTN_OK))
  {
    detectJunction();

    if(finishDetected)
    {
      brakeMotor();
      oled.clear();
      oled.setCursor(15, 3);
      oled.print("FINISH REACHED!");
      delay(2000);
      break;
    }
    else if(crossJunction || rightJunction)
    {
      turnRight();
    }
    else if(leftJunction)
    {
      if(straightPath)
      {
        goStraight();
      }
      else
      {
        turnLeft();
      }
    }
    else if(deadEnd)
    {
      uTurn();
    }
    else
    {
      calculatePID();
    }
  }

  stopMotor();
}

//-------------------------------------

void straightMode()
{
  runStartTime = millis();
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("RUN: STRAIGHT MODE");
  oled.setCursor(0, 6);
  oled.print("[OK: Stop]");

  while(!button(BTN_OK))
  {
    detectJunction();

    if(finishDetected)
    {
      brakeMotor();
      oled.clear();
      oled.setCursor(15, 3);
      oled.print("FINISH REACHED!");
      delay(2000);
      break;
    }
    else if(crossJunction)
    {
      goStraight();
    }
    else if(leftJunction)
    {
      if(straightPath)
      {
        goStraight();
      }
      else
      {
        turnLeft();
      }
    }
    else if(rightJunction)
    {
      if(straightPath)
      {
        goStraight();
      }
      else
      {
        turnRight();
      }
    }
    else if(deadEnd)
    {
      uTurn();
    }
    else
    {
      calculatePID();
    }
  }

  stopMotor();
}

//-------------------------------------

void statePriorityMode()
{
  runStartTime = millis();
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("RUN: STATE PRIORITY");
  oled.setCursor(0, 6);
  oled.print("[OK: Stop]");

  while(!button(BTN_OK))
  {
    detectJunction();

    if(finishDetected)
    {
      brakeMotor();
      oled.clear();
      oled.setCursor(15, 3);
      oled.print("FINISH REACHED!");
      delay(2000);
      break;
    }

    if(lastTurn == 'L')
    {
      if(leftJunction)
      {
        turnLeft();
        lastTurn = 'L';
      }
      else if(rightJunction)
      {
        turnRight();
        lastTurn = 'R';
      }
      else if(deadEnd)
      {
        uTurn();
      }
      else
      {
        calculatePID();
      }
    }
    else if(lastTurn == 'R')
    {
      if(rightJunction)
      {
        turnRight();
        lastTurn = 'R';
      }
      else if(leftJunction)
      {
        turnLeft();
        lastTurn = 'L';
      }
      else if(deadEnd)
      {
        uTurn();
      }
      else
      {
        calculatePID();
      }
    }
    else
    {
      if(crossJunction)
      {
        goStraight();
        lastTurn = 'S';
      }
      else if(leftJunction)
      {
        turnLeft();
        lastTurn = 'L';
      }
      else if(rightJunction)
      {
        turnRight();
        lastTurn = 'R';
      }
      else if(deadEnd)
      {
        uTurn();
      }
      else
      {
        calculatePID();
      }
    }
  }

  stopMotor();
}

//-------------------------------------

void combineMode()
{
  runStartTime = millis();
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("COMBINE MODE (COMP)");
  oled.setCursor(0, 2);
  oled.print("1. Map Exploration");
  oled.setCursor(0, 4);
  oled.print("2. Path Optimize");
  oled.setCursor(0, 6);
  oled.print("Press OK to Start");

  while(!button(BTN_OK));
  delay(300);

  pathIndex = 0;
  bool reachedFinish = false;

  while(!button(BTN_OK))
  {
    detectJunction();

    if(finishDetected)
    {
      brakeMotor();
      reachedFinish = true;
      break;
    }
    else if(deadEnd)
    {
      uTurn();
      optimizePath();
    }
    else if(crossJunction || leftJunction)
    {
      turnLeft();
      optimizePath();
    }
    else if(rightJunction)
    {
      if(straightPath)
      {
        goStraight();
      }
      else
      {
        turnRight();
      }
      optimizePath();
    }
    else
    {
      calculatePID();
    }
  }

  stopMotor();

  if(reachedFinish)
  {
    oled.clear();
    oled.setCursor(0, 1);
    oled.print("MAZE COMPLETED!");
    oled.setCursor(0, 3);
    oled.print("Opt Path: ");
    for(int i = 0; i < pathIndex; i++)
    {
      oled.print(path[i]);
    }
    delay(2000);

    runShortestPath();
  }
}
