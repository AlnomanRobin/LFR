#define EEPROM_MAGIC 0x5A

void saveCalibration()
{
  EEPROM.update(100, EEPROM_MAGIC);
  for(byte i=0; i<6; i++)
  {
    EEPROM.put(i*2, sensorMid[i]);
  }
}

void loadCalibration()
{
  if (EEPROM.read(100) == EEPROM_MAGIC)
  {
    for(byte i=0; i<6; i++)
    {
      EEPROM.get(i*2, sensorMid[i]);
    }
  }
  else
  {
    // Default fallback midpoint if uncalibrated
    for(byte i=0; i<6; i++)
    {
      sensorMid[i] = 512;
    }
  }
}
