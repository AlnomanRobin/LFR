void inverseModeRun()
{
 inverseMode=true;

 while(!button(BTN_OK))
 {
   calculatePID();
 }

 stopMotor();

 inverseMode=false;
}