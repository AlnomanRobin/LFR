/****************************************
   CHAMPIONSHIP STRAIGHT RUN / RACE MODE
****************************************/

void lineFollow()
{
  runStartTime   = millis();
  gapStartTime   = 0;
  floodStartTime = 0;
  lastError      = 0;

  oled.clear();
  oled.setCursor(0, 0);
  oled.print("RACE MODE ACTIVE");
  oled.setCursor(0, 3);
  oled.print("Tracks: Gap/Inv/V");
  oled.setCursor(0, 6);
  oled.print("[OK: Stop]");

  bool finished = false;

  while(!button(BTN_OK))
  {
    // Auto-detect inverted sections and finish box
    if(checkAutoInverseAndFinish(finished))
    {
      if(finished)
      {
        brakeMotor();
        digitalWrite(LED_PIN, HIGH);
        oled.clear();
        oled.set2X();
        oled.setCursor(20, 2);
        oled.print("WINNER!");
        oled.set1X();
        oled.setCursor(10, 5);
        oled.print("FINISH REACHED");
        delay(2500);
        digitalWrite(LED_PIN, LOW);
        break;
      }
      continue;
    }

    calculatePID();
  }

  stopMotor();
}
