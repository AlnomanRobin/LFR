String menuItem(byte i)
{
  switch(i)
  {
    case 1: return "Motor Test";
    case 2: return "Sensor Test";
    case 3: return "Straight Run";
    case 4: return "Left Priority";
    case 5: return "Right Priority";
    case 6: return "State Priority";
    case 7: return "Inverse Mode";
    case 8: return "Combine Mode";
    case 9: return "Calibration";
  }

  return "";
}

void displayMenu()
{
  oled.clear();
  oled.set1X();
  oled.setCursor(0, 0);
  oled.print("== ARISE LFR ==");

  oled.setCursor(0, 3);
  oled.print(" > ");
  oled.print(menuItem(menuIndex));

  oled.setCursor(0, 7);
  oled.print("[UP/DN:Sel OK:Run]");
}

void menuSystem()
{
  displayMenu();

  while(1)
  {
    if(button(BTN_UP))
    {
      menuIndex--;
      if(menuIndex < 1) menuIndex = 9;
      displayMenu();
    }

    if(button(BTN_DOWN))
    {
      menuIndex++;
      if(menuIndex > 9) menuIndex = 1;
      displayMenu();
    }

    if(button(BTN_OK))
    {
      oled.clear();

      switch(menuIndex)
      {
        case 1: motorTest(); break;
        case 2: sensorTest(); break;
        case 3: lineFollow(); break;
        case 4: leftPriorityMode(); break;
        case 5: rightPriorityMode(); break;
        case 6: statePriorityMode(); break;
        case 7: inverseModeRun(); break;
        case 8: combineMode(); break;
        case 9: calibration(); break;
      }

      displayMenu();
    }
  }
}
