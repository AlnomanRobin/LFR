void motor(int left,int right)
{
  digitalWrite(LFWD, left > 0);
  digitalWrite(LBWD, left < 0);

  digitalWrite(RFWD, right > 0);
  digitalWrite(RBWD, right < 0);

  analogWrite(LPWM, constrain(abs(left), 0, 255));
  analogWrite(RPWM, constrain(abs(right), 0, 255));
}

void stopMotor()
{
  motor(0, 0);
}

void brakeMotor()
{
  motor(-255, -255);
  delay(20);

  stopMotor();
}

void motorTest()
{
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("MOTOR TEST");

  const char* stages[] = {
    "LEFT FORWARD",
    "LEFT BACKWARD",
    "RIGHT FORWARD",
    "RIGHT BACKWARD",
    "BOTH FORWARD",
    "BOTH BACKWARD"
  };

  int testSpeeds[6][2] = {
    {180, 0},
    {-180, 0},
    {0, 180},
    {0, -180},
    {180, 180},
    {-180, -180}
  };

  for(byte s = 0; s < 6; s++)
  {
    oled.setCursor(0, 2);
    oled.print(stages[s]);
    oled.print("       ");
    oled.setCursor(0, 6);
    oled.print("[OK: Abort]");

    motor(testSpeeds[s][0], testSpeeds[s][1]);

    unsigned long start = millis();
    while(millis() - start < 1200)
    {
      if(button(BTN_OK))
      {
        stopMotor();
        return;
      }
    }
    brakeMotor();
    delay(300);
  }

  stopMotor();
}
