/****************************************
   CHAMPIONSHIP PID & TRACK RECOVERY
****************************************/

void calculatePID()
{
  digitalSensor();

  int weight[6] = { -5, -3, -1, 1, 3, 5 };

  long sum = 0;
  byte activeCount = 0;

  for(byte i = 0; i < 6; i++)
  {
    if(sensorDigital[i])
    {
      sum += weight[i];
      activeCount++;
    }
  }

  // -------------------------------------------------------------
  // 1. GAP CROSSING & ACUTE ANGLE RECOVERY (LINE LOST: activeCount == 0)
  // -------------------------------------------------------------
  if(activeCount == 0)
  {
    // A. Dashed Line / Gap on Straight Track:
    if(abs(lastError) < 2.0)
    {
      if(gapStartTime == 0) gapStartTime = millis();

      if(millis() - gapStartTime < GAP_TIMEOUT)
      {
        motor(gapSpeed, gapSpeed);
        return;
      }
    }

    // B. Acute Angle Recovery (< 45 deg sharp turns / zig-zags):
    // Pivot spin towards the side where the line was last seen
    if(lastError > 0)
    {
      motor(turnSpeed, -turnSpeed);
    }
    else if(lastError < 0)
    {
      motor(-turnSpeed, turnSpeed);
    }
    return;
  }

  // Line is acquired -> Reset gap timer
  gapStartTime = 0;

  // -------------------------------------------------------------
  // 2. POSITION & DYNAMIC SPEED
  // -------------------------------------------------------------
  error = (float)sum / activeCount;

  // Auto Speed Boost on straight lines
  if(sensorDigital[2] && sensorDigital[3] && !sensorDigital[0] && !sensorDigital[5])
  {
    baseSpeed = 220; // Full throttle on straight
  }
  else
  {
    // Reduce speed on curves for maximum grip
    baseSpeed = 175 - (int)(abs(error) * 12);
    baseSpeed = constrain(baseSpeed, 120, 175);
  }

  // -------------------------------------------------------------
  // 3. PID FORMULATION
  // -------------------------------------------------------------
  integral = constrain(integral + error, -80, 80);

  float derivative = error - lastError;

  float PID = (Kp * error) + (Ki * integral) + (Kd * derivative);

  int left  = baseSpeed + (int)PID;
  int right = baseSpeed - (int)PID;

  left  = constrain(left, -255, 255);
  right = constrain(right, -255, 255);

  motor(left, right);

  lastError = error;
}
