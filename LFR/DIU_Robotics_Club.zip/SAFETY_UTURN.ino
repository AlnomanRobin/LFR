void safeUTurn()
{
  brakeMotor();

  motor(-200,200);

  delay(320);

  while(
     !sensorDigital[2] &&
     !sensorDigital[3]
  )
  {
     digitalSensor();
  }

  stopMotor();

  storePath('B');
}