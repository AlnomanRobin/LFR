void readSensor()
{
  for(byte i=0; i<6; i++)
  {
    sensorValue[i] = analogRead(sensorPin[i]);
  }
}

void digitalSensor()
{
  readSensor();

  for(byte i=0; i<6; i++)
  {
    sensorDigital[i] = (sensorValue[i] > sensorMid[i]) ? 1 : 0;
  }

  if(inverseMode)
  {
    for(byte i=0; i<6; i++)
    {
      sensorDigital[i] = !sensorDigital[i];
    }
  }
}

void sensorTest()
{
  oled.clear();

  while(!button(BTN_OK))
  {
    digitalSensor();

    oled.setCursor(0, 0);
    oled.print("SENSOR TEST:");

    oled.setCursor(0, 3);
    oled.print("D: [");
    for(byte i=0; i<6; i++)
    {
      oled.print(sensorDigital[i]);
      oled.print(" ");
    }
    oled.print("]");

    oled.setCursor(0, 6);
    oled.print("[OK: Exit]");
    delay(50);
  }

  delay(200);
}

void calibration()
{
  oled.clear();
  oled.setCursor(0, 0);
  oled.print("CALIBRATING...");
  oled.setCursor(0, 2);
  oled.print("Sweeping track...");

  for(byte i=0; i<6; i++)
  {
    sensorMin[i] = 1023;
    sensorMax[i] = 0;
  }

  unsigned long startCalibTime = millis();
  while(millis() - startCalibTime < 3500)
  {
    if((millis() - startCalibTime) % 600 < 300)
    {
      motor(-130, 130);
    }
    else
    {
      motor(130, -130);
    }

    for(byte i=0; i<6; i++)
    {
      int val = analogRead(sensorPin[i]);
      if(val < sensorMin[i]) sensorMin[i] = val;
      if(val > sensorMax[i]) sensorMax[i] = val;
    }
  }

  stopMotor();

  for(byte i=0; i<6; i++)
  {
    sensorMid[i] = (sensorMin[i] + sensorMax[i]) / 2;
  }

  saveCalibration();

  oled.clear();
  oled.setCursor(0, 1);
  oled.print("CALIBRATION OK!");
  oled.setCursor(0, 3);
  oled.print("Mid saved to EEPROM");
  delay(1500);
}
