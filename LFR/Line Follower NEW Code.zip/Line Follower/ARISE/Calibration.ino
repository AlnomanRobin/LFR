void cal() {
  oled.clear();
  oled.set2X();
  text("  START  ", 10, 3, 0);

  for (byte i = 0; i < 6; i++) {
    minimum[i] = 1023;
    maximum[i] = 0;
  }

  while (!push(sw)) {
    for (byte i = 0; i < 6; i++) {
      (i < 4) ? s[i] = analogRead(i) : s[i] = analogRead(i + 2);
      minimum[i] = min(s[i], minimum[i]);
      maximum[i] = max(s[i], maximum[i]);
    }
  }


  for (byte i = 0; i < 6; i++) {
    th[i] = minimum[i] + (maximum[i] - minimum[i]) * cal_p;
    if(th[i]<512) th[i]= 512 ;
    EEPROM.write(i, minimum[i] / 4);
    EEPROM.write(i + 6, th[i] / 4);
    EEPROM.write(i + 12, maximum[i] / 4);
  }
}






void calibration() {
  oled.clear();
  oled.set2X();
  text("CALIBRATE", 10, 3, 0);

  byte i = 0;
  while (i < 21) {
    text(".", i * 6, 6, 0);
    delay(50);
    i++;
    if (push(sw)) break;
  }

  if (i >= 21) cal();


  oled.clear();
  oled.set1X();
  text("MIN", 0, 0, 0);
  text("MID", 0, 3, 0);
  text("MAX", 0, 6, 0);
  for (byte i = 0; i < 3; i++) {
    text(String(minimum[i]), 35 * (i + 1), 0, 0);
    text(String(minimum[5 - i]), 35 * (i + 1), 1, 0);
    text(String(th[i]), 35 * (i + 1), 3, 0);
    text(String(th[5 - i]), 35 * (i + 1), 4, 0);
    text(String(maximum[i]), 35 * (i + 1), 6, 0);
    text(String(maximum[5 - i]), 35 * (i + 1), 7, 0);
  }
  while (!push(sw))
    ;
}






void memory_restore() {
  for (byte i = 0; i < 6; i++) {
    minimum[i] = EEPROM.read(i) * 4;
    th[i] = EEPROM.read(i + 6) * 4;
    maximum[i] = EEPROM.read(i + 12) * 4;
  }

}




