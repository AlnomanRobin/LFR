String menu_option(byte a) {
  if (a == 1) return "Analog Reading                   ";
  else if (a == 2) return "Calibration                  ";
  else if (a == 3) return "Digital Reading              ";
  else if (a == 4) return "Line Follow L                ";
  else if (a == 5) return "Line Follow R                 ";
 // else return "                    ";
}



byte menu() {
  byte base = 1, peak = base + 4, temp = 0, index = 1, limit = 5;
  oled.clear();
  oled.set1X();

  while (1) {
    if (index != temp) {
      temp = index;
      for (byte i = base; i <= peak; i++) (i == index) ? text("-" + menu_option(i), 0, (i - base), 1) : text("-" + menu_option(i), 0, (i - base), 0);
    }

    byte r = push(sw);
    if (r == 2) return 0;
    if (r == 1) return index;

    r = push(up);
    if (r == 1) {
      index--;
      if (index == 0) {
        index = limit;
        (index > 5) ? peak = index : peak = 5;
        base = peak - 4;
      }
      if (index < base) {
        base = index;
        peak = base + 4;
      }
    }



    r = push(dn);
    if (r == 1) {
      index++;
      if (index > limit) {
        index = 1;
        base = index;
        peak = base + 4;
      }
      if (index > peak) {
        peak = index;
        base = peak - 4;
      }
    }
  }
}





