void brake(int x) {
  if (x) {
    motor(-250, -250);
    delay(x);
  }
  motor(0, 0);
  delay(50);
}



void motor(int a, int b) {
  digitalWrite(lmf, (a > 0));
  digitalWrite(lmb, (a < 0));
  digitalWrite(rmf, (b > 0));
  digitalWrite(rmb, (b < 0));
  analogWrite(lms, min(abs(a), 255));
  analogWrite(rms, min(abs(b), 255));
}


