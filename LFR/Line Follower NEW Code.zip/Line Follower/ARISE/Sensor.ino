void reading(bool mode) {
  sum = 0;
  sensor = 0;
 
  for (byte i = 0; i < 6; i++) {
    (i < 4) ? s[i] = analogRead(i) : s[i] = analogRead(i + 2);
    if (mode) {
      (s[i] > th[i]) ? s[i] = 1  : s[i] = 0 ;  //digital conversion
      sensor += s[i] * base[i];
   
      sum += s[i];
    }
  
   
  }
/*
  Serial.print("sensor= ");
  Serial.print(sensor);
  Serial.print("   ");
  Serial.print("sum= ");
  Serial.println(sum);
*/
}





void analog_display() {
  oled.clear();
  oled.set2X();
  while (!push(sw)) {
  reading(0);



    
    for (byte i = 0; i < 3; i++) 
    
    {
      String value = "";
      if (s[5 - i] < 1000) value += " ";
      if (s[5 - i] < 100) value += " ";
      if (s[5 - i] < 10) value += " ";
      value += String(s[5 - i]) + "  " + String(s[0 + i]) + "        ";
      text(value, 4, 6 - i * 3, 0);
     
    }
    
  }
}







void digital_display() {
  oled.clear();
  oled.set2X();
  while (!push(sw)) {
  reading(1);
   for (byte i = 0; i < 6; i++) text(String(s[5 - i]), i * 23, 0, 0);
  }
}



