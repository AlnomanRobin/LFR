void inverse_line() {
  bool got = 0;
  if (s[0] && s[5]) {
    t1 = millis();
    while (s[0] && s[5] && sum < 6) {
      reading(1);
      if (millis() - t1 > i_timer) {
        got = 1;
       // i_mode = !i_mode;
       // oled.invertDisplay(i_mode);
        break;
      }
    }
    if (!got) {
     // turn = side;
     // t2 = millis();
      motor(- 10 * spl, 10 * spr) ;
        while (!s[2] && !s[3]) reading(1);
        motor(0,0);
        turn = 's';
        cross='s';
        motor(10 * spl, 10 * spr);
    }
  }
}




