#include "SSD1306Ascii.h"
#include "SSD1306AsciiWire.h"
#include <NewPing.h>
// #include <EEPROM.h>

NewPing sonarF(9, 9, 30), sonarR(10, 10, 30), sonarL(8, 8, 30);
byte sf, sl, sr;

SSD1306AsciiWire oled;

//for motors
// byte spl = 15, spr = 15;
// byte lms = 3, lmf = 4, lmb = 5, rmf = 6, rmb = 7, rms = 11;
byte up = 0, dn = 2; 
// byte sw = 1, led = 13;
byte spd = 10;
// byte base_L, base_R;

//for sensors
// int s[6], minimum[6], maximum[6], pos = 0; 
// byte sensor, base[6] = { 1, 2, 4, 8, 16, 32 };
int th[6] = { 512, 512, 512, 512, 512, 512 };
// byte sum;
// float avg, error = 0, last_error = 0, set_point = 3.5, PID;
// int kp, kd;
// short int motorL, motorR;

//for lfr
int brake_delay = 40, tsp = 100, stop_timer = 100, node_delay = 20, U_turn_delay, turn_delay;
byte disF, count, turnDiff, i_timer, wall_mid, wall_p;
char turn = 's', cross = 's', side = 's';
float cal_p = 0.5, lineP = 3;
byte path[20], memory = 50, LFR[3];
bool cont = 0, i_mode = 0;

//for timing
unsigned long t1, t2, s1, s2, s3;







void setup() {
  Wire.begin();
  Wire.setClock(400000L);
  oled.begin(&Adafruit128x64, 0x3C);
  oled.setFont(System5x7);
 // Serial.begin(9600);
  pinMode(up, INPUT_PULLUP);
  pinMode(dn, INPUT_PULLUP);
 // pinMode(sw, INPUT_PULLUP);
  pinMode(led, OUTPUT);

  memory_restore();
  path_load();
  for (byte i = 0; i < 6; i++) Serial.println(String(minimum[i]) + " " + String(th[i]) + " " + String(maximum[i]));
  intro();
  
}




void loop() {


  byte j = push(sw);
  if (j) {
    byte r = menu();
    if (r) {
      if (r == 1) adjustment();
      if (r == 2) calibration();
      if (r == 3) analog_display();
      if (r == 4) digital_display();
      if (r == 5) {
        oled.clear();
        oled.set2X();
        text("  Ready?  ", 4, 3, 0);
        delay(1000);
        motor(base_L, base_R);
        while (!push(sw))
          ;
        motor(0, 0);
      }

      if (r == 6) path_clear();

      if (r == 7) {
        oled.clear();
        oled.set2X();
        text(" TURNING ", 10, 3, 0);
        fixed_turn('r');
      }
      if (r == 8) wall_follow();
    }
    intro();
  }





  j = push(up);
  if (j) {
    if (j == 1) counter();
    if (j == 2) path_display();
    intro();
  }



  j = push(dn);
  if (j) {
    byte r = lfr_select();
    if (r) {
      if (r == 1) lfr();
      if (r == 2) lfr();
      if (r == 3) pid_follow();
    }
    intro();
  }
}
