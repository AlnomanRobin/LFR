String lfr_option(byte a) {
  if (a == 1) return "     Simple LFR     ";
  else if (a == 2) return "     Manual LFR     ";
  else if (a == 3) return "     Simple PID     ";
}

byte lfr_select() {
  byte temp = 0, index = 1, limit = 3;
  int speed = EEPROM.read(20) * 10;
  oled.clear();
  oled.set1X();
  text("   Select Bot Mode   ", 1, 1, 0);
  text("Speed:" + String(speed) + "   Count:" + String(count), 0, 7, 0);
  while (1) {
    if (index != temp) {
      temp = index;
      for (byte i = 1; i <= limit; i++) (i == index) ? text(lfr_option(i), 4, i + 2, 1) : text(lfr_option(i), 4, i + 2, 0);
    }
    byte r = push(sw);
    if (r == 2) return 0;
    if (r == 1) return index;

    r = push(up);
    if (r == 1) {
      index--;
      if (index < 1) index = limit;
    }

    r = push(dn);
    if (r == 1) {
      index++;
      if (index > limit) index = 1;
    }
  }
}

