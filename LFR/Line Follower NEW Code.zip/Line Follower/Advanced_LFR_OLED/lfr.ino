
void lfr() {
  oled.clear();
  oled.set2X();
  text(" LFR Mode ", 10, 3, 0);


  count = EEPROM.read(19);
  cont = 0;



  while (1) {

start:
    reading(1);
    if (path[count] == 14) {
      cont = 1;
      count++;
    }
    if (sum == 0) {  // turn execute
      if (turn != 's') {
        if (path[count] == 6) count++;
        if (path[count] == 7) {
          count++;
          turn = 's';
          goto start;
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? pos = 5 : pos = -5;
        turn = 's';
        motor(10 * spl, 10 * spr);
      }

      else if (abs(pos) < 3) {
        if (L_check(0)) wall_follow();
        t1 = millis();
        bool gap = 1;
        while (sum == 0) {
          reading(1);
          if (millis() - t1 > U_turn_delay) {
            gap = 0;
            turn = 'l';
            t2 = millis();
            if (path[count] == 8) {
              count++;
              cont = 0;
            }
          }
        }
        if (gap && path[count] == 9) {
          count++;
          cont = 0;
        }
      }
    }

    else if (sum == 1 || sum == 2) {
      if (path[count] == 11) obstacle('r');
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (sum) reading(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 5 : pos = -5;
        cross = 's';
        motor(10 * spl, 10 * spr);
      }
      if (sensor == B001100) {
        if (pos) {
          (pos > 0) ? motor(250, -250) : motor(-250, 250);
          delay(2 * abs(pos));
          pos = 0;
        }
        motor(10 * spl, 10 * spr);
      }

      else if (sensor == B001000) motor(9 * spl, 10 * spr);
      else if (sensor == B000100) motor(10 * spl, 9 * spr);

      else if (sensor == B011000) {
        if (pos < 1) pos = 1;
        motor((float)(9 - lineP) * spl, 10 * spr);
      }

      else if (sensor == B000110) {
        if (pos > -1) pos = -1;
        motor(10 * spl, (float)(9 - lineP) * spr);
      }

      else if (sensor == B010000) {
        if (pos < 2) pos = 2;
        motor((float)(9 - lineP * 2) * spl, 10 * spr);
      }

      else if (sensor == B000010) {
        if (pos > -2) pos = -2;
        motor(10 * spl, (float)(9 - lineP * 2) * spr);
      }

      else if (sensor == B110000) {
        if (pos < 3) pos = 3;
        motor((float)(9 - lineP * 3) * spl, 10 * spr);
      }

      else if (sensor == B000011) {
        if (pos > -3) pos = -3;
        motor(10 * spl, (float)(9 - lineP * 3) * spr);
      }

      else if (sensor == B100000) {
        if (pos < 4) pos = 4;
        motor((float)(9 - lineP * 4) * spl, 10 * spr);
      }

      else if (sensor == B000001) {
        if (pos > -4) pos = -4;
        motor(10 * spl, (float)(9 - lineP * 4) * spr);
      }
    }

    else if (sum >= 3 && sum <= 5) {
       inverse_line();
      if (!s[0] && s[5] && (s[3] || s[2])) {
        turn = 'l';
        if (path[count] == 1 || path[count] == 2 || (cont && side == 'l')) {
          while (!s[0] && s[5]) reading(1);
          if (!s[5]) {
            delay(node_delay);
            reading(1);
            if (sum) {
              if (path[count] == 1 || cont) cross = side = 'l';
              count++;
              digitalWrite(led, 1);
            }
          }
        }
      }

      if (s[0] && !s[5] && (s[3] || s[2])) {
        turn = 'r';
        if (path[count] == 3 || path[count] == 2 || (cont && side == 'r')) {
          while (s[0] && !s[5]) reading(1);
          if (!s[0]) {
            delay(node_delay);
            reading(1);
            if (sum) {
              if (path[count] == 3 || cont) cross = side = 'r';
              count++;
              digitalWrite(led, 1);
            }
          }
        }
      }
      t2 = millis();
    }

    else {  //sum 6
      turn = side;
      t1 = millis();
      while (sum == 6) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          motor(0, 0);
          while (sum == 6) reading(1);
          goto start;
        }
      }
      //this point onward indicates that robot didn't find any end point
      delay(node_delay);
      reading(1);
      if (sum) {
        if (cont) cross = side;
        if (path[count] == 5) {
          cont = 0;
          (path[count + 1] == 1) ? cross = side = 'l' : cross = side = 'r';
          count += 2;
          digitalWrite(led, 1);
        }
      }

      else {
        if (path[count] == 4) {
          cont = 0;
          (path[count + 1] == 1) ? turn = 'l' : turn = 'r';
          count += 2;
          digitalWrite(led, 1);
        }
      }
      t2 = millis();
    }
    if (millis() - t2 > 200) {
      turn = 's';
      digitalWrite(led, 0);
    }
  }
}
*/