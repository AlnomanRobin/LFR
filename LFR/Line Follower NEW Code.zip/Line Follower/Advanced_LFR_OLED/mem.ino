void memory_restore() {
  for (byte i = 0; i < 6; i++) {
    minimum[i] = EEPROM.read(i) * 4;
    th[i] = EEPROM.read(i + 6) * 4;
    maximum[i] = EEPROM.read(i + 12) * 4;
  }



  count = EEPROM.read(19);
  int speed = EEPROM.read(20);
  int error = EEPROM.read(21) - 25;
  (error > 0) ? spr = speed - error : spr = speed;
  (error < 0) ? spl = speed + error : spl = speed;
  base_L = spl * 10;
  base_R = spr * 10;
  node_delay = EEPROM.read(22);
  brake_delay = EEPROM.read(23) * 10;
  tsp = EEPROM.read(24) * 10;
  stop_timer = EEPROM.read(25) * 10;
  U_turn_delay = EEPROM.read(26) * 10;
  disF = EEPROM.read(27);
  cal_p = (float)EEPROM.read(28) / 10;
  lineP = (float)EEPROM.read(29) / 10;
  kp = EEPROM.read(30);
  kd = EEPROM.read(31) * 10;
  turn_delay = EEPROM.read(32) * 10;
  turnDiff = EEPROM.read(33);
  i_timer = EEPROM.read(34);
  wall_mid = EEPROM.read(35);
  wall_p = EEPROM.read(36);
}



void path_load() {
  for (byte i = 0; i < 20; i++) path[i] = EEPROM.read(memory + i);
}



void path_clear() {
  oled.clear();
  oled.set2X();
  text(" WARNING! ", 4, 1, 0);
  oled.set1X();
  text(" Data will be erased ", 1, 4, 0);
  text("Short Press to cancel", 1, 6, 0);
  while (1) {
    byte r = (push(sw));
    if (r) break;
    if (!digitalRead(up) && !digitalRead(dn)) {
      oled.clear();
      text("Erasing path data....", 1, 4, 0);
      delay(800);
      for (byte i = 0; i < 20; i++) {
        EEPROM.write(memory + i, 0);
        path[i] = 0;
        delay(10);
      }
      oled.clear();
      text("  Path Data erased!  ", 1, 4, 0);
      delay(1000);
      break;
    }
  }
  intro();
}


/*

 String adj_option(byte a) {
   if (a == 1) return "Motor Speed     ";
   else if (a == 2) return "Motor Error     ";
   else if (a == 3) return "Node Delay      ";
   else if (a == 4) return "Motor Brake     ";
   else if (a == 5) return "Turn Speed      ";
   else if (a == 6) return "Stop Timer      ";
   else if (a == 7) return "U-Turn Delay    ";
   else if (a == 8) return "Detect Front    ";
   else return "                    ";
 }
*/
