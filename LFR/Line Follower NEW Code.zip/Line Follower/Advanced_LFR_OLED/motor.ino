/*
void motor(int a, int b) {
  digitalWrite(lmf, (a > 0));
  digitalWrite(lmb, (a < 0));
  digitalWrite(rmf, (b > 0));
  digitalWrite(rmb, (b < 0));
  analogWrite(lms, min(abs(a), 255));
  analogWrite(rms, min(abs(b), 255));
}



void brake(int x) {
  if (x) {
    motor(-250, -250);
    delay(x);
  }
  motor(0, 0);
  delay(50);
}
*/


void fixed_turn(char x) {
  motor(0, 0);
  delay(1000);
  (x == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
  delay(turn_delay);
  (x == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
  delay(40);
  motor(0, 0);
  delay(1000);
}
