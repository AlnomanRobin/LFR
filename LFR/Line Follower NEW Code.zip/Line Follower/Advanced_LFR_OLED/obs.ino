
void obstacle(char x) {
  if (F_check(0) < disF) {
    brake(brake_delay);
    fixed_turn(x);
    reading(1);
    (x == 'r') ? motor(base_L - turnDiff, base_R) : motor(base_L, base_R - turnDiff);
    while (sum == 0) reading(1);
    while (sum) reading(1);
    delay(node_delay);
    brake(brake_delay);
    fixed_turn(x);
    cont = 0;
  }
}

void wall_follow() {
  while (!sum) {
    reading(1);
     if (F_check(1) < disF) fixed_turn('l');
    while (L_check(1)) {
     if (F_check(1) < disF) fixed_turn('r');
      int error = wall_mid - sl;
      if (abs(error) > 1) motor(base_L + error * wall_p, base_R - error * wall_p);
    }

    while (R_check(1)) {
      if (F_check(1) < disF) fixed_turn('l');
      int error = wall_mid - sr;
      if (abs(error) > 1) motor(base_L - error * wall_p, base_R + error * wall_p);
    }

    motor(base_L, base_R);
  }
}

