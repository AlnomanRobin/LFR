String path_option(byte a) {
  if (a == 0) return "----------";
  else if (a == 1) return "LEFT      ";
  else if (a == 2) return "STRAIGHT  ";
  else if (a == 3) return "RIGHT     ";
  else if (a == 4) return "T DETECT  ";
  else if (a == 5) return "CROSS FIND";
  else if (a == 6) return "90 DETECT ";
  else if (a == 7) return "90 SKIP   ";
  else if (a == 8) return "U TURN    ";
  else if (a == 9)  return "LINE GAP  ";
  else if (a == 10) return "INVERSE   ";
  else if (a == 11) return "OBSTACLE  ";
  else if (a == 12) return "WALL DET. ";
  else if (a == 11) return "STOP NOW  ";
  else if (a == 12) return "CONTINUE  ";
  else return "INVALID   ";
}




void path_display() {
  byte base = 1, peak = base + 7, temp = 0, index = 1, limit = 20;
  String value;
  oled.clear();
  oled.set1X();
  while (1) {
    if (index != temp) {
      temp = index;
      for (byte i = base; i <= peak; i++) {
        (i < 10) ? value = "0" + String(i) : value = String(i);
        (i == index) ? text(value + ". " + path_option(path[i - 1]), 1, (i - base), 1) : text(value + ". " + path_option(path[i - 1]), 1, (i - base), 0);
      }
    }




    byte r = push(sw);
    if (r == 1) {
      path_adjust(index - 1);
      temp = 0;
    }
    if (r == 2) {
      intro();
      return;
    }
    r = push(up);
    if (r == 1) {
      index--;
      if (index == 0) {
        index = limit;
        (index > 8) ? peak = index : peak = 8;
        base = peak - 7;
      }
      if (index < base) {
        base = index;
        peak = base + 7;
      }
    }

    r = push(dn);
    if (r == 1) {
      index++;
      if (index > limit) {
        index = 1;
        base = index;
        peak = base + 7;
      }
      if (index > peak) {
        peak = index;
        base = peak - 7;
      }
    }
  }
}






void path_adjust(byte i) {
  oled.clear();
  oled.set2X();
  int val, limit = 12, temp = -1;
  String value;
  byte u, d;
  val = path[i];

  while (1) {
    if (temp != val) {
      temp = val;
      text(path_option(val), 4, 3, 0);
    }

    u = cont_push(up, u);
    if (u) {
      val++;
      if (val > limit) val = limit;
    }


    d = cont_push(dn, d);
    if (d) {
      val--;
      if (val < 0) val = 0;
    }


    byte r = push(sw);
    if (r) {
      if (r == 1) {
        EEPROM.write(i + memory, val);
        path[i] = val;
        delay(10);
      }
      oled.clear();
      oled.set1X();
      return;
    }




  }
}

