/*
void pid_follow() {
  oled.clear();
  oled.set2X();
  text(" PID Mode ", 1, 3, 0);
  while (!push(sw)) {
    reading(1);
    error = set_point - avg;
    PID = error * kp + (error - last_error) * kd;
    last_error = error;
    motorL = base_L + (int)PID;
    motorR = base_R - (int)PID;
    motor(motorL, motorR);
  }
  motor(0, 0);
  digitalWrite(led, 0);
}
*/
