byte push(byte pin) {
  byte count = 0;
  bool longPress = 0;
  int t = 0;
  if (!digitalRead(pin)) {       //if the button is pressed
    delay(20);                   //debounce delay
    while (!digitalRead(pin)) {  //wait while the button is pressed
      delay(1);
      t++;
       if (t > 300 && !longPress)
       if(t>300) 
    {
        digitalWrite(led, 1);
        longPress = 1;
      }
    }
    digitalWrite(led, 0);
    if (longPress) return 2;
    else if (t) return 1;
  }
  return 0;
}





byte cont_push(byte pin, bool a) {
  byte count = 0;
  int t = 0;
  if (!digitalRead(pin)) {       //if the button is pressed
    delay(20);                   //debounce delay
    while (!digitalRead(pin)) {  //wait while the button is pressed
      delay(1);
      t++;
      if (t > 300 || a) return 1;
    }
    if (t) return 1;
  }
  return 0;
}

