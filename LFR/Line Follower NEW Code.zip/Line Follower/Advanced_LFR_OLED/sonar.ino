
byte F_check(bool a) {
  if (millis() - s1 > 30 || a) {
    s1 = millis();
    sf = sonarF.ping_cm();
    if (sf <= 2) sf = 30;
  }
  return sf;
}

byte L_check(bool a) {
  if (millis() - s2 > 30 || a) {
    s2 = millis();
    sl = sonarL.ping_cm();
    if (sl >= 25) sl = 0;
  }
  return sl;
}

byte R_check(bool a) {
  if (millis() - s3 > 30 || a) {
    s3 = millis();
    sr = sonarR.ping_cm();
    if (sr >= 25) sr = 0;
  }
  return sr;
}

