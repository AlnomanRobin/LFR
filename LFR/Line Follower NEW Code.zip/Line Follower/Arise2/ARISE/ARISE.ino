#include <Wire.h>
#include "SSD1306Ascii.h"
#include "SSD1306AsciiWire.h"
SSD1306AsciiWire oled;
#include<EEPROM.h>

#define sw 1
#define up 0
#define dn 2
#define led 13
byte j;


byte lms = 3, lmf = 4, lmb = 5, rmf = 6, rmb = 7, rms = 11;



byte sum, spl = 15, spr = 15 , i_timer=20;
int s[6],minimum[6], maximum[6],th[6],pos = 0;
byte sensor, base[6] = { 1, 2, 4, 8, 16, 32 };
float cal_p = 0.5,lineP = 3 ;
bool i_mode=0;
unsigned long t2,t1;
char turn = 's', cross = 's', side = 's';
int stop_timer = 200, node_delay = 150, U_turn_delay=300,  brake_delay = 20;




void setup() {
  pinMode(sw, INPUT_PULLUP);
  pinMode(up, INPUT_PULLUP);
  pinMode(dn, INPUT_PULLUP);
  pinMode(led, OUTPUT);
  Serial.begin(9600);

  Wire.begin();
  Wire.setClock(400000L);
  oled.begin(&Adafruit128x64, 0x3C);
  oled.setFont(System5x7);
  intro();
  memory_restore();

 
}



void loop() 
{
  
    byte j = push(sw);
    if (j) {
    byte r = menu();
    if (r) {
      if (r == 1) analog_display();
      if (r == 2) calibration();
      if (r == 3) digital_display();
      if (r == 4) lfrL();
      if (r == 5) lfrR();
    }
    intro();
  }


reading(1);

   
 
  
}






