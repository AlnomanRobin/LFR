# include<EEPROM.h>
// for motors
byte enA = 11, in1 = 7, in2 = 6, in3 = 4, in4 = 5, enB = 3;
byte base_L = 200, base_R = 200  ;
float avg = 0, error = 0,  PID = 0 , last_error = 0 ;
int kp = 100 , kd = 300 ;
float motorL, motorR;

//for sensors
#define S0 8
#define S1 9
#define S2 10
#define S3 12
#define SIG_PIN A0
int s[10], mid[10] , minimum[10] , maximum[10] , th = 100 , brake_delay = 20 , node_delay = 50; 
byte sum , PID_sensor ; 
int sensor , base[10] = { 1, 2, 4, 8, 16, 32 , 64 , 128 , 256 , 512}; 

void setup() {
pinMode(enA,OUTPUT);
pinMode(enB,OUTPUT);
pinMode(in1,OUTPUT);
pinMode(in2,OUTPUT);
pinMode(in3,OUTPUT);
pinMode(in4,OUTPUT);

pinMode(S0, OUTPUT);
pinMode(S1, OUTPUT);
pinMode(S2, OUTPUT);
pinMode(S3, OUTPUT);

Serial.begin(9600);

// delay(10000);
    for (int i = 0; i < 10; i++) 
  {
    mid[i] = EEPROM.read(i) * 4;
    maximum[i] = EEPROM.read(i + 10) * 4;
    minimum[i] = EEPROM.read(i + 20) * 4;

    Serial.print(i);
    Serial.print("  max=");
    Serial.print(maximum[i]);
    Serial.print(" ");

    Serial.print("mid=");
    Serial.print(mid[i]);
    Serial.print(" ");

    Serial.print("min=");
    Serial.println(minimum[i]); 
  }

}

void loop() {
//  motor(base_L, base_R);
//  motor(-base_L, -base_R);
//  motor(0,0);
//  motor(base_L, 0);
//  motor(-base_L, 0);
//  motor(0, base_R);
//  motor(0, -base_R);
//  reading(0);
//  reading(1);
  run();
//  cal();
}
