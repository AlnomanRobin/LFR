void cal() 

{
  for (int i = 0; i < 10; i++) 
  {
    maximum[i] = 0;
    minimum[i] = 1023;
  }
  motor(-200, 200);

 for (int i = 0; i < 6000 ; i++) 
  {
for (byte i = 3; i < 13; i++) {
    delayMicroseconds(20);
    selectChannel(i);
    s[12-i] = analogRead(SIG_PIN);
    maximum[12-i] = max(maximum[12-i], s[12-i]);
    minimum[12-i] = min(minimum[12-i], s[12-i]);
  }
  }

  motor(0, 0);

  for (int i = 0; i < 10; i++) 
  {
    mid[i] = (maximum[i] + minimum[i]) / 3;
    EEPROM.write(i, mid[i] / 4); delay(10);
    EEPROM.write(i + 10, maximum[i] / 4); delay(10);
    EEPROM.write(i + 20, minimum[i] / 4); delay(10);
  }

  delay(30000000000);
}
