void text(String t, int x, int y, bool color) {
  oled.setInvertMode(color);
  oled.setCursor(x, y);
  oled.print(t);
}

void intro() {
  oled.set2X();
  oled.clear();
  text("  ARISE  ", 10, 3, 0);
}

void analog_display() {
  oled.clear();
  oled.set2X();
  while (!push(sw)) {
  reading(0);    
    for (byte i = 0; i < 3; i++)     
    {
      String value = "";
      if (s[5 - i] < 1000) value += " ";
      if (s[5 - i] < 100) value += " ";
      if (s[5 - i] < 10) value += " ";
      value += String(s[5 - i]) + "  " + String(s[0 + i]) + "                 ";
      text(value, 4, 6 - i * 3, 0);     
    }
  }
}

void digital_display() {
  oled.clear();
  oled.set2X();
  while (!push(sw)) {
   reading(1);
   for (byte i = 0; i < 6; i++) text(String(s[5 - i]), i * 23, 0, 0);
   String value = "";
   if (sensor < 10) value += " ";
   value += String(sensor) + "  " + String(error,1) + "                      ";
   text( value, 4, 3, 0);
   value = " ";
   value += String(sum) + "  " + String(PID,1) + "                       ";
   text( value, 4, 6, 0);
  }
}

void calibration() {
  oled.clear();
  oled.set2X();
  text("CALIBRATE", 10, 3, 0);

  byte i = 0;
  while (i < 21) {
    text(".", i * 6, 6, 0);
    delay(50);
    i++;
    if (push(sw)) break;
  }

  if (i >= 21) cal();
  oled.clear();
  oled.set1X();
  text("MIN", 0, 0, 0);
  text("MID", 0, 3, 0);
  text("MAX", 0, 6, 0);
  for (byte i = 0; i < 3; i++) {
    text(String(minimum[i]), 35 * (i + 1), 0, 0);
    text(String(minimum[5 - i]), 35 * (i + 1), 1, 0);
    text(String(th[i]), 35 * (i + 1), 3, 0);
    text(String(th[5 - i]), 35 * (i + 1), 4, 0);
    text(String(maximum[i]), 35 * (i + 1), 6, 0);
    text(String(maximum[5 - i]), 35 * (i + 1), 7, 0);
  }
  while (!push(sw)) ;
}
