void pid() {
    motorL = base_L + (int)PID;
    motorR = base_R - (int)PID;
    motor(motorL, motorR);
}

void mixed()
{
    if (sensor == B001100) {
        if (pos != 0) {
          (pos > 0) ? motor(200, -200) : motor(-200, 200);
          delay(2 * abs(pos));
          pos = 0;
        }
         pid();
      }

      else if (sensor == B001000)   pid();  
      else if (sensor == B000100)   pid();         

      else if (sensor == B011000) {
        if (pos < 1) pos = 1;
        pid();
      }
      else if (sensor == B000110) {
        if (pos > -1) pos = -1;
        pid();
      }

      else if (sensor == B010000) {
        if (pos < 2) pos = 2;
        pid();
      }
      else if (sensor == B000010) {
        if (pos > -2) pos = -2;
        pid();
      }

      else if (sensor == B110000) {
        if (pos < 3) pos = 3;
        pid();
      }
      else if (sensor == B000011) {
        if (pos > -3) pos = -3;
        pid();
      }
      
      else if (sensor == B100000) {
        if (pos < 4) pos = 4;
        pid();
      }
      else if (sensor == B000001) {
        if (pos > -4) pos = -4;
        pid();
      }
}

void mixed_4()
{
    if (sensor == B001100) {
        if (pos != 0) {
          (pos > 0) ? motor(200, -200) : motor(-200, 200);
          delay(2 * abs(pos));
          pos = 0;
        }
         pid();
      }

      else if (sensor == B001000)   pid();  
      else if (sensor == B000100)   pid();         

      else if (sensor == B011000) {
        if (pos < 1) pos = 1;
        pid();
      }
      else if (sensor == B000110) {
        if (pos > -1) pos = -1;
        pid();
      }

      else if (sensor == B010000) {
        if (pos < 2) pos = 2;
        pid();
      }
      else if (sensor == B000010) {
        if (pos > -2) pos = -2;
        pid();
      }
}
