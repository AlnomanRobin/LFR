void motor(int a, int b) {
  digitalWrite(lmf, (a > 0));
  digitalWrite(lmb, (a < 0));
  digitalWrite(rmf, (b > 0));
  digitalWrite(rmb, (b < 0));
  analogWrite(lms, min(abs(a), 200));
  analogWrite(rms, min(abs(b), 200));
}

void brake(int x) {
  if (x) {
    motor(-200, -200);
    delay(x);
  }
  motor(0, 0);
  delay(80);
}

void node_delay_check()
{
  motor(base_L, base_R);
  delay(node_delay);
  brake(brake_delay);
}
