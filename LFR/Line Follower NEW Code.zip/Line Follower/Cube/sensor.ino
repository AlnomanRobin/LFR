void reading(bool mode) {
  sum = 0;
  sensor = 0;
  byte PID_sensor = 0;
  for (byte i = 0; i < 6; i++) {
    delayMicroseconds(20);
    (i < 4) ? s[i] = analogRead(i) : s[i] = analogRead(i + 2);
    if (mode) {
      (s[i] > th[i]) ? s[i] = 1 ^ i_mode : s[i] = 0 ^ i_mode;  
      sensor += s[i] * base[i];
      PID_sensor += s[i] * (i + 1);
      sum += s[i];
    }
  }
  if (sum) avg = (float)PID_sensor / sum;
  error = 3.5 - avg;
  PID = error * kp ;
}

void cal() {
  oled.clear();
  oled.set2X();
  text("  START  ", 10, 3, 0);

  for (byte i = 0; i < 6; i++) {
    minimum[i] = 1023;
    maximum[i] = 0;
  }

  while (!push(sw)) {
    for (byte i = 0; i < 6; i++) {
      (i < 4) ? s[i] = analogRead(i) : s[i] = analogRead(i + 2);
      minimum[i] = min(s[i], minimum[i]);
      maximum[i] = max(s[i], maximum[i]);
    }
  }

  for (byte i = 0; i < 6; i++) {
    th[i] = minimum[i] + ((maximum[i] - minimum[i]) * cal_p);
    EEPROM.write(i, minimum[i] / 4);
    delay(10);
    EEPROM.write(i + 6, th[i] / 4);
    delay(10);
    EEPROM.write(i + 12, maximum[i] / 4);
    delay(10);
  }
  memory_restore() ;
}
