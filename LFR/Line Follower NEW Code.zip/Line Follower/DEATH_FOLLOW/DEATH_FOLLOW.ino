#include<EEPROM.h>

// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 240, rbase = 240;
// motor end



// sensor start-- 5 array
int s_5_array[5], sum_5_array ;
int base_5_array[5] = { 1, 2, 4, 8, 16 };
int  sums_5_array;
// sensor end-- 5 array



// basic line follow start
float lsp = 19, rsp = 19, line_prop=2.5 ;
int pos=0;
// basic line follow end

int node_delay=100;
int U_turn_time=50;

// 90,45 degree turn start
char turn='s';
uint32_t m1,m2,m3;
// 90,45 degree turn end

// T,cross,right T, left T section start
char cross='s';
char side='l'; // left hand rule or right hand rule
// T,cross,right T, left T section end


void setup() 
{
  // Serial monitor start
  Serial.begin(9600);

 

  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end

  


}


void reading_5_array() 
{
  sums_5_array = 0;
  sum_5_array = 0;
  for (byte i=4;i>=0;i--) 
  {
    s_5_array[i] = analogRead[i];
    (s_5_array[i] > 95) ? s_5_array[i] = 1 : s_5_array[i] = 0; 
    sums_5_array = sums_5_array+(s_5_array[i] * base_5_array[i]);
    sum_5_array = sum_5_array+s_5_array[i];
  }

  Serial.print("sums= ");
  Serial.print(sums_5_array);
  Serial.print("  ");
  Serial.print("sum= ");
  Serial.println(sum_5_array);
}



void loop()
{
    reading_5_array();



   
}


