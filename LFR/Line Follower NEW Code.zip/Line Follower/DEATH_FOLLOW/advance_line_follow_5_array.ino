void advance_line_follow_5_array() 
{
    
 a:   reading_5_array();



    if (sum_5_array == 0)
    {
      if (turn != 's') 
        {
        motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
        delay(node_delay);                                    
        (turn == 'r') ?  motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp); 
        while (!s_5_array[2]) reading_5_array();                     
        turn = 's'; 
        }

        // U turn

        else if(pos>-3 && pos <3)
        {
          m3=millis();
          while(sum_5_array ==0)
          {
            reading_5_array();
            if((millis()-m3) > (node_delay+U_turn_time))
            {
              motor(0,0); delay(100);
              (side='r')? motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp); 
              while (!s_5_array[2]) reading_5_array();                     
              pos=0;
              break;
            }

          }
        }
        
    }







    else if (sum_5_array == 1 || sum_5_array == 2) 

    {  


      if(cross!='s') // right,left T section
      {
        (cross=='r')? motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
        while(s_5_array[2]+s_5_array[3]+s_5_array[1]) reading_5_array();
        while (!s_5_array[2]) reading_5_array();
        cross=='s';
      }




      if (sums_5_array == 0b00100) 
      {

        if (pos != 0) {
          (pos > 0) ? motor(-10 * lsp, 10 * rsp) : motor(10 * lsp, -10 * rsp);
          delay(abs(pos) * 5);
          pos=0;
        }

        motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
      }



      //for right side turn correction
      else if (sums_5_array  == 0b00110) 
      {
        motor((10 + 1*line_prop) * lsp, (10 - 1*line_prop) * rsp);
      }
      else if (sums_5_array  == 0b00010)  
      {
        if (pos < 1) pos = 1;
        motor((10 + 2*line_prop) * lsp, (10 - 2*line_prop) * rsp);
      }

      else if (sums_5_array  == 0b00011) 
       {
        if (pos < 2) pos = 2;
        motor((10 + 3*line_prop) * lsp, (10 - 3*line_prop) * rsp);
      }

      else if (sums_5_array  == 0b00001) {
        if (pos < 3) pos = 3;
        motor((10 + 4*line_prop) * lsp, (10 - 4*line_prop) * rsp);
      }

      
      





      //for left side turn detection
      else if (sums_5_array  == 0b01100) 
      {
        motor((10 - 1*line_prop) * lsp, (10 + 1*line_prop) * rsp);
      }

      else if (sums_5_array  == 0b01000)  {
        if (pos > -1) pos = -1;
       motor((10 - 2*line_prop) * lsp, (10 + 2*line_prop) * rsp);
      }

      else if (sums_5_array  == 0b11000) {
        if (pos > -2) pos = -2;
        motor((10 - 3*line_prop) * lsp, (10 + 3*line_prop) * rsp);
      }

      else if (sums_5_array  == 0b10000) {
        if (pos > -3) pos = -3;
        motor((10 - 4*line_prop) * lsp, (10 + 4*line_prop) * rsp);
      }

      

      
      


    }






     else if (sum_5_array >= 3 && sum_5_array <= 4) 
    {  
      //sharp turn detection
      if (s_5_array[2] && s_5_array[0] && !s_5_array[4])
       {
        turn = 'r'; // sharp turn--90,45 degree
        if(side=='r') // right hand rule
        {
          while(s_5_array[0] && !s_5_array[4]) reading_5_array(); // it will be broken when-- T or cross or right T section or sharp turn
         if(!s_5_array[4]) // right T section or sharp turn -- confirmed
         {
          delay(node_delay);
          reading_5_array();
          if(sum_5_array !=0) 
          {
            turn='s' ;
            cross='r'; // right T section -- confirmed
          }
         }
        }
      }  

      if ((s_5_array[2]) && s_5_array[4] && !s_5_array[0]) 
      {
        turn = 'l';
        if(side=='l') // left hand rule
        {
          while(!s_5_array[0] && s_5_array[4]) reading_5_array(); // it will be broken when-- T or cross or left T section or sharp turn
         if(!s_5_array[0]) // left T section or sharp turn -- confirmed
         {
          delay(node_delay);
          reading_5_array();
          if(sum_5_array !=0)
          {
            turn='s' ;
            cross='l'; // left T section -- confirmed
          }  
         }
        }
      }  
      m1=millis();
    }





    else if (sum_5_array == 5) 
    {
     turn=side;
     motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
     m3=millis();
     while(s_5_array[4]==1 && s_5_array[0]==1) 
     {
     reading_5_array();
     if ((millis()-m3)>node_delay) 
     {  //detection of stop point
     motor(0, 0);
     while (sum_5_array == 5) reading_5_array();
     goto a;
     }

     }
     delay(node_delay);
     reading_5_array();
     if(sum_5_array !=0) goto a;

    }



   m2=millis();
   {
     if((m2-m1) > node_delay)  turn='s';    
   }
    

  
}
