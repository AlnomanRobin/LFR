void analog_read_5_array() 
{
  for (short int i=4;i>=0;i--)
  { 
    Serial.print(analogRead(i));
    Serial.print(" ");
  }  
  Serial.println();
}




