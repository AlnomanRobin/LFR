// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 160, rbase = 160;
// motor end

// button start
int r;
# define sw 2
# define LED 13
// button end

// sensor start-- 8 array
int s_8_array[8], sum_8_array ;
int base_8_array[8] = { 1, 2, 4, 8, 16, 32 , 64 , 128 };
int  sums_8_array;
int threshold=100;
// sensor end-- 8 array

// basic line follow start
float lsp = 16, rsp = 16, line_prop=2.5 ;
int pos=0;
// basic line follow end

int node_delay=100;
uint32_t m1,m2,m3;



void setup()
{
  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end

  // Serial monitor start
  Serial.begin(9600);

  pinMode(sw, INPUT_PULLUP);
  pinMode(LED, OUTPUT);

}

void loop()
{
   int r = button_read();
   Serial.println(r);
   // motor(160, 160);
   // motor(0, 0);
   // motor(-160,-160);
   // motor(160, 0);
   // motor(-160, 0);
   // motor(0, 160);
   // motor(0, -160);
   // motor(100, 100);
   // motor(50, 50);

   // if(r==1) analog_read_8_array();
   // analog_read_8_array();
   // if(r==2) digitalread_8_array();
   // digitalread_8_array();
   // reading_8_array();
   // D();
   // if(r==3) basic_line_follow_8_array();
   // basic_line_follow_8_array();

}








