void D() 
{
    
 a:   reading_8_array();



    if (sum_8_array == 0)
    {
        
    }




    else if (sum_8_array == 1 || sum_8_array == 2) 

    {  
      if (sums_8_array == 0b00011000) 
      {
        if (pos != 0) 
        {
          (pos > 0) ? motor(-10 * lsp, 10 * rsp) : motor(10 * lsp, -10 * rsp);
          delay(abs(pos) * 5000);
          pos=0;
        }
        motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
      }



      //for right side turn correction
      else if (sums_8_array  == 0b00001000) 
      {
        motor((10 + 1*line_prop) * lsp, (10 - 1*line_prop) * rsp);
      }
      else if (sums_8_array  == 0b00001100)  
      {
        if (pos < 1) pos = 1;
        motor((10 + 2*line_prop) * lsp, (10 - 2*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000100) 
       {
        if (pos < 2) pos = 2;
        motor((10 + 3*line_prop) * lsp, (10 - 3*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000110) {
        if (pos < 3) pos = 3;
        motor((10 + 4*line_prop) * lsp, (10 - 4*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000010) {
        if (pos < 4) pos = 4;
       motor((10 + 5*line_prop) * lsp, (10 - 5*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000011) {
        if (pos < 5) pos = 5;
        motor((10 + 6*line_prop) * lsp, (10 - 6*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000001) {
        if (pos < 6) pos = 6;
        motor((10 + 7*line_prop) * lsp, (10 - 7*line_prop) * rsp);
      }






      //for left side turn detection
      else if (sums_8_array  == 0b00010000) 
      {
        motor((10 - 1*line_prop) * lsp, (10 + 1*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00110000)  {
        if (pos > -1) pos = -1;
       motor((10 - 2*line_prop) * lsp, (10 + 2*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00100000) {
        if (pos > -2) pos = -2;
        motor((10 - 3*line_prop) * lsp, (10 + 3*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b01100000) {
        if (pos > -3) pos = -3;
        motor((10 - 4*line_prop) * lsp, (10 + 4*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b01000000) {
        if (pos > -4) pos = -4;
        motor((10 - 5*line_prop) * lsp, (10 + 5*line_prop) * rsp);
      }

      
      else if (sums_8_array  == 0b11000000) {
        if (pos > -5) pos = -5;
        motor((10 - 6*line_prop) * lsp, (10 + 6*line_prop) * rsp);
      }


      else if (sums_8_array  == 0b10000000) {
        if (pos > -6) pos = -6;
       motor((10 - 7*line_prop) * lsp, (10 + 7*line_prop) * rsp);
      }


    }






     else if (sum_8_array >= 3 && sum_8_array <= 7) 
    {  

    }




    else if (sum_8_array == 8) 
    {


     motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
     m3=millis();
     while(s_8_array[7]==1 || s_8_array[0]==1) 
     {
     reading_8_array();
     if ((millis()-m3)>node_delay) 
     {  //detection of stop point
     motor(0, 0);
     while (sum_8_array == 8) reading_8_array();
     goto a;
     }

     }



    }

    

  
}












