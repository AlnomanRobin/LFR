// button start
int r;
# define sw 2
# define LED 13
// button end


void setup() 
{
  // Serial monitor start
  Serial.begin(9600);

  pinMode(sw, INPUT_PULLUP);
  pinMode(LED, OUTPUT);

}

void loop() 
{
   int r = button_read();
   Serial.println(r); 

}








