int button_read() 

{
    int count = 0;
p:  int t = 0;

    if (digitalRead(sw) == 0) 
 {   
    digitalWrite(LED, HIGH);
    while (digitalRead(sw) == 0) 
    {
      delay(1); t++;
    }
    digitalWrite(LED, LOW);


    if (t > 25) // to avoid mechanical error, real press > 50 ms
    {
      t = 0; count++;
      while (digitalRead(sw) == 1) 
      {
        delay(1); t++;
        if (t > 2000) return count; // wait 2s for another press
      }
      goto p;
    }
  }
  // return count;

}






