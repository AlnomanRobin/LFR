# include<EEPROM.h>

// button start
int r;
# define sw 2
# define LED 13
// button end


void setup() 
{
  // Serial monitor start
  Serial.begin(9600);

  pinMode(sw, INPUT_PULLUP);
  pinMode(LED, OUTPUT);
  r = EEPROM.read(1)*4;
  Serial.println(r);

}

void loop() 
{


   int r = button_read();
   Serial.println(r); 
   if(r==1)
   {
    EEPROM.write(1,r/4);
    digitalWrite(LED,1);
   }

   if(r==2)
   {
    EEPROM.write(1,r/4);
    digitalWrite(LED,0);
   }




}







