# include<EEPROM.h>

// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 200, rbase = 200;
int brake_time=0;
int turn_brake=0;
// motor end



// sensor start-- 8 array
int s_8_array[8], sum_8_array ;
int base_8_array[8] = { 1, 2, 4, 8, 16, 32 , 64 , 128 };
int  sums_8_array;
 int threshold=250;
// sensor end-- 8 array




// basic line follow start
float lsp = 20, rsp = 20, line_prop=2.5 ;
int pos=0;
// basic line follow end



float node_delay=150;



// sharp turn start
char turn='s';
uint32_t m1,m2,m3;
// sharp turn end



// T,cross,right T, left T section start
char cross='s';
char side='l'; // left hand rule or right hand rule
// T,cross,right T, left T section end


// button start
int r;
# define sw 2
# define LED 13
// button end


// calibration start
 int maximum_8_array[8], minimum_8_array[8], mid_8_array[8] ,s_8_array_cal[8]; 
// calibration end




void setup()
{

  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end

  // button start
   pinMode(sw, INPUT_PULLUP);
  pinMode(LED, OUTPUT);
  // button end

  // Serial monitor start
  Serial.begin(9600);


  

   delay(2000);

  // EEPROM test start

  // Serial.print("r=");
  // r = EEPROM.read(60);
  // Serial.println(r);
  

  // EEPROM test end


/*
  for (int i = 0; i < 8; i++) 
  {
    mid_8_array[i] = EEPROM.read(i) * 4;
    maximum_8_array[i] = EEPROM.read(i + 8) * 4;
    minimum_8_array[i] = EEPROM.read(i + 16) * 4;
    
    Serial.print(i);
    Serial.print(")  max=");
    Serial.print(maximum_8_array[i]);
    Serial.print(" ");

    Serial.print("mid=");
    Serial.print(mid_8_array[i]);
    Serial.print(" ");

    Serial.print("min=");
    Serial.println(minimum_8_array[i]); 
  }


*/

}




void loop()
{   
   // r=button_read();
  // Serial.println(r);
  //  EEPROM.write(60,r);

  // if(r==1) cal_8_array();
  // cal_8_array();

   // if(r==2) T_U();



   // analog_read_8_array();
     T_U();

  

  

    //if(r==3) analog_read_8_array();
   

   // if(r==4) digitalread_8_array();
   // digitalread_8_array();

   // if(r==5) reading_8_array();
   // reading_8_array();






   // motor(200, 200);
   // motor(0, 0);
  // motor(-180,-180);
  // motor(180, 0);
  // motor(-180, 0);
  // motor(0, 180);
  // motor(0, -180);
  // motor(100, 100);
  // motor(60, 60);
  // D();
  


  // EEPROM test start

  /*
   if(r==1)
   {
    EEPROM.write(1,r/4);
    digitalWrite(LED,1);
   }

   if(r==2)
   {
    EEPROM.write(1,r/4);
    digitalWrite(LED,0);
   }

   */


   // EEPROM test end



   

}
















