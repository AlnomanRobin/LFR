void T_U() 
{
    
  a:  reading_8_array();






    if (sum_8_array == 0)
    {


       if (turn != 's') // 90,45 degree turn
        {

        motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
        delay(node_delay); 
        brake();                                   
        (turn == 'r') ?  motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp); 
        while (!s_8_array[4] && !s_8_array[3]) reading_8_array();
        (turn == 'l') ?  motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
        delay(turn_brake);
        turn = 's';
        goto a; 

        }





        else if(pos>-4 && pos<4)  // U turn
        {
          motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
          m2=millis();
          while(sum_8_array == 0)
          {
            reading_8_array();
            if((millis()-m2)>(node_delay*1.4))
            {
              brake();
              (side=='r')? motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp); 
              while (!s_8_array[4] && !s_8_array[3]) reading_8_array();
              (side == 'l') ?  motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
              delay(turn_brake);
              pos=0;
              goto a;
            }

          }
        }
        
    }













    else if (sum_8_array == 1 || sum_8_array == 2) 

    {  



      if(cross!='s') // right,left T section,cross,T
      {
        brake();
        (cross=='r')? motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
        while(s_8_array[5]+s_8_array[4]+s_8_array[3]+s_8_array[2]) reading_8_array();
        while (!s_8_array[4] && !s_8_array[3]) reading_8_array();
        (cross == 'l') ?  motor((10 - 0*line_prop) * lsp, -(10 - 0*line_prop) * rsp) :  motor(-(10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
        delay(turn_brake);
        cross=='s';
        goto a;
      }






      if (sums_8_array == 0b00011000) 
      {
        if (pos != 0) {
          (pos > 0) ? motor(-10 * lsp, 10 * rsp) : motor(10 * lsp, -10 * rsp);
          delay(abs(pos) * 5);
          pos=0;
        }
        motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
      }



      //for right side turn correction
      else if (sums_8_array  == 0b00001000) 
      {
        motor((10 + 1*line_prop) * lsp, (10 - 1*line_prop) * rsp);
      }
      else if (sums_8_array  == 0b00001100)  
      {
        if (pos < 1) pos = 1;
        motor((10 + 2*line_prop) * lsp, (10 - 2*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000100) 
       {
        if (pos < 2) pos = 2;
        motor((10 + 3*line_prop) * lsp, (10 - 3*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000110) {
        if (pos < 3) pos = 3;
        motor((10 + 4*line_prop) * lsp, (10 - 4*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000010) {
        if (pos < 4) pos = 4;
       motor((10 + 5*line_prop) * lsp, (10 - 5*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000011) {
        if (pos < 5) pos = 5;
        motor((10 + 6*line_prop) * lsp, (10 - 6*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000001) {
        if (pos < 6) pos = 6;
        motor((10 + 7*line_prop) * lsp, (10 - 7*line_prop) * rsp);
      }






      //for left side turn detection
      else if (sums_8_array  == 0b00010000) 
      {
        motor((10 - 1*line_prop) * lsp, (10 + 1*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00110000)  {
        if (pos > -1) pos = -1;
       motor((10 - 2*line_prop) * lsp, (10 + 2*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00100000) {
        if (pos > -2) pos = -2;
        motor((10 - 3*line_prop) * lsp, (10 + 3*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b01100000) {
        if (pos > -3) pos = -3;
        motor((10 - 4*line_prop) * lsp, (10 + 4*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b01000000) {
        if (pos > -4) pos = -4;
        motor((10 - 5*line_prop) * lsp, (10 + 5*line_prop) * rsp);
      }

      
      else if (sums_8_array  == 0b11000000) {
        if (pos > -5) pos = -5;
        motor((10 - 6*line_prop) * lsp, (10 + 6*line_prop) * rsp);
      }


       else if (sums_8_array  == 0b10000000) {
       if (pos > -6) pos = -6;
       motor((10 - 7*line_prop) * lsp, (10 + 7*line_prop) * rsp);
      }

      
      // Y turn

     





    }







     else if (sum_8_array >= 3 && sum_8_array <= 7) 
    {  
      //  cross, left T, right T, T, left 90 degree, right 90 degree

      if ((s_8_array[3] + s_8_array[4]) && s_8_array[0] && !s_8_array[7]) // right 90 degree,cross,T,right T

      {
        turn = 'r'; // sharp turn-- right 90,45 degree
        if(side=='r') // right hand rule
        {
         while(s_8_array[0] && !s_8_array[7]) reading_8_array(); // it will be broken when-- T or cross or right T section or right 90 degree
         if(!s_8_array[7]) // right T section or right 90 degree -- confirmed
         {
          motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
          delay(10);
          motor(0,0);
          reading_8_array();
          if(sum_8_array !=0) 
          {
            motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
            delay(node_delay-10);
            turn='s' ;
            cross='r'; // right T section -- confirmed

            goto a;
          }
         }
        }
      }







     else if ((s_8_array[4] + s_8_array[3]) && s_8_array[7] && !s_8_array[0])  // left 90 degree,cross,T,left T

       { 
         
        turn = 'l'; // sharp turn-- left 90,45 degree
        if(side=='l') // left hand rule
        {
          while(!s_8_array[0] && s_8_array[7]) reading_8_array(); // it will be broken when-- T or cross or left T section or left 90 degree
         if(!s_8_array[0]) // left T section or left 90 degree -- confirmed
         {
          motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
          delay(10);
          motor(0,0);
          reading_8_array();
          if(sum_8_array !=0) 
          {
            motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
            delay(node_delay-10);
            turn='s' ;
            cross='l'; // left T section -- confirmed

            goto a;
          }  
         }
        }
      }  





    // Y turn

   



     



      





else 
{
    motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp); 
}

      m1=millis(); // sharp turn -- valid within node delay

      



    }






    else if (sum_8_array == 8)  // T, cross, start,end
    {


     turn=side; // for T section
     



     motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
     m3=millis();
     while(s_8_array[7]==1 || s_8_array[0]==1) 
     {
     reading_8_array();
     if ((millis()-m3)>100) 
     {  //detection of stop point
     motor(0, 0);
     while (s_8_array[7]==1 || s_8_array[0]==1 || s_8_array[4]==1 || s_8_array[3]==1) reading_8_array();
     goto a;
     }

     }
     




     delay(10);
     reading_8_array();
     if(sum_8_array !=0)
     {
      
      turn='s';
     }

    }





    
   
  if((millis()-m1) > (3*node_delay))  
  {
    turn='s';   // sharp turn -- valid within node delay 
    cross='s';
  }
   
  
}










