void cal_8_array() 

{
  for (int i = 0; i < 8; i++) 
  {
    maximum_8_array[i] = 0;
    minimum_8_array[i] = 1023;
  }
  motor(200, -200);

  for (int i = 0; i < 6000 ; i++) 
  {
    for (int i = 0; i < 8 ; i++) 
    {
      s_8_array_cal[i] = analogRead(i);
      maximum_8_array[i] = max(maximum_8_array[i], s_8_array_cal[i]);
      minimum_8_array[i] = min(minimum_8_array[i], s_8_array_cal[i]);
    }
  }

  motor(0, 0);


  for (int i = 0; i < 8; i++) 
  {
    mid_8_array[i] = (maximum_8_array[i] + minimum_8_array[i]) / 2;
    EEPROM.write(i, mid_8_array[i] / 4); delay(10);
    EEPROM.write(i + 8, maximum_8_array[i] / 4); delay(10);
    EEPROM.write(i + 16, minimum_8_array[i] / 4); delay(10);
  }


  
  delay(30000);
  
}














