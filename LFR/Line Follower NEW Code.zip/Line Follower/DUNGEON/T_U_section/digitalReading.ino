void digitalread_8_array() 
{
  
  sums_8_array = 0;
  sum_8_array = 0;
  for ( int i=7;i>=0;i--) 
  {
    s_8_array[i] = analogRead(i);
    // Serial.print(s_8_array[i]);
    //Serial.print(s_8_array[i]);
    (s_8_array[i] > threshold) ? s_8_array[i] = 1 : s_8_array[i] = 0; 
    Serial.print(s_8_array[i]);
    Serial.print(" ");
  }
  Serial.println();

}








