// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 160, rbase = 160;
// motor end

// sensor start-- 8 array
int s_8_array[8], sum_8_array ;
int base_8_array[8] = { 1, 2, 4, 8, 16, 32 , 64 , 128 };
int  sums_8_array;
int threshold=100;
// sensor end-- 8 array

// basic line follow start
float lsp = 16, rsp = 16, line_prop=2.5 ;
int pos=0;
// basic line follow end

int node_delay=100;
uint32_t m1,m2,m3;



void setup()
{
  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end

  // Serial monitor start
  Serial.begin(9600);

}



void reading_8_array() 
{
  sums_8_array = 0;
  sum_8_array = 0;
  for (byte i=7;i>=0;i--) 
  {
    s_8_array[i] = analogRead[i];
    (s_8_array[i] > threshold) ? s_8_array[i] = 1 : s_8_array[i] = 0; 
    sums_8_array = sums_8_array+(s_8_array[i] * base_8_array[i]);
    sum_8_array = sum_8_array+s_8_array[i];
  }

  Serial.print("sums= ");
  Serial.print(sums_8_array);
  Serial.print("   ");
  Serial.print("sum= ");
  Serial.println(sum_8_array);
}












void loop()
{
   {
    
   a: reading_8_array();



    if (sum_8_array == 0)
    {
        
    }




    else if (sum_8_array == 1 || sum_8_array == 2) 

    {  
      if (sums_8_array == 0b00011000) 
      {
        if (pos != 0) {
          (pos > 0) ? motor(-10 * lsp, 10 * rsp) : motor(10 * lsp, -10 * rsp);
          delay(abs(pos) * 5);
          pos=0;
        }
        motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
      }



      //for right side turn correction
      else if (sums_8_array  == 0b00001000) 
      {
        motor((10 + 1*line_prop) * lsp, (10 - 1*line_prop) * rsp);
      }
      else if (sums_8_array  == 0b00001100)  
      {
        if (pos < 1) pos = 1;
        motor((10 + 2*line_prop) * lsp, (10 - 2*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000100) 
       {
        if (pos < 2) pos = 2;
        motor((10 + 3*line_prop) * lsp, (10 - 3*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000110) {
        if (pos < 3) pos = 3;
        motor((10 + 4*line_prop) * lsp, (10 - 4*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000010) {
        if (pos < 4) pos = 4;
       motor((10 + 5*line_prop) * lsp, (10 - 5*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000011) {
        if (pos < 5) pos = 5;
        motor((10 + 6*line_prop) * lsp, (10 - 6*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00000001) {
        if (pos < 6) pos = 6;
        motor((10 + 7*line_prop) * lsp, (10 - 7*line_prop) * rsp);
      }






      //for left side turn detection
      else if (sums_8_array  == 0b00010000) 
      {
        motor((10 - 1*line_prop) * lsp, (10 + 1*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00110000)  {
        if (pos > -1) pos = -1;
       motor((10 - 2*line_prop) * lsp, (10 + 2*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b00100000) {
        if (pos > -2) pos = -2;
        motor((10 - 3*line_prop) * lsp, (10 + 3*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b01100000) {
        if (pos > -3) pos = -3;
        motor((10 - 4*line_prop) * lsp, (10 + 4*line_prop) * rsp);
      }

      else if (sums_8_array  == 0b01000000) {
        if (pos > -4) pos = -4;
        motor((10 - 5*line_prop) * lsp, (10 + 5*line_prop) * rsp);
      }

      
      else if (sums_8_array  == 0b11000000) {
        if (pos > -5) pos = -5;
        motor((10 - 6*line_prop) * lsp, (10 + 6*line_prop) * rsp);
      }


      else if (sums_8_array  == 0b10000000) {
        if (pos > -6) pos = -6;
       motor((10 - 7*line_prop) * lsp, (10 + 7*line_prop) * rsp);
      }


    }






     else if (sum_8_array >= 3 && sum_8_array <= 7) 
    {  

    }




    else if (sum_8_array == 8) 
    {
      
     motor((10 - 0*line_prop) * lsp, (10 - 0*line_prop) * rsp);
     m3=millis();
     while(s_8_array[7]==1 || s_8_array[0]==1) 
     {
     reading_8_array();
     if ((millis()-m3)>node_delay) 
     {  //detection of stop point
     motor(0, 0);
     while (s_8_array[7]==1 || s_8_array[0]==1 || s_8_array[3]==1 || s_8_array[4]==1) reading_8_array();
     goto a;
     }

     }




    }

    

  
}













}







