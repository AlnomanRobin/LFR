#include<EEPROM.h>

// button start
int r;
# define sw 2
# define LED 13
// button end

// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 160, rbase = 160;
// motor end




// calibration start
int maximum_8_array[8], minimum_8_array[8], mid_8_array[8] ,s_8_array_cal[8]; 
// calibration end



void setup() 
{
  // Serial monitor start
  Serial.begin(9600);

  pinMode(sw, INPUT_PULLUP);
  pinMode(LED, OUTPUT);

  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end

  for (int i = 0; i < 8; i++) 
  {
    mid_8_array[i] = EEPROM.read(i) * 4;
    maximum_8_array[i] = EEPROM.read(i + 8) * 4;
    minimum_8_array[i] = EEPROM.read(i + 16) * 4;
    
    Serial.print(i);
    Serial.print(")  max=");
    Serial.print(maximum_8_array[i]);
    Serial.print(" ");

    Serial.print("mid=");
    Serial.print(mid_8_array[i]);
    Serial.print(" ");

    Serial.print("min=");
    Serial.println(minimum_8_array[i]); 
  }




}

void loop() 
{
   int r = button_read();
   Serial.println(r); 
   if(r==1) cal_8_array();

   // cal_8_array();

}






