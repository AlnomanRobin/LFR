void motor(float b, float a)
{
   
   if(a>0)
   {
    if(a>rbase)
    {
      a=rbase;
    }
    digitalWrite(in1,1);
    digitalWrite(in2,0);

   }



   else

   {
    a=-a;
    if(a>rbase)
    {
      a=rbase;
    }
    digitalWrite(in1,0);
    digitalWrite(in2,1);

   }




   if(b>0)
   {
    if(b>lbase)
    {
      b=lbase;
    }
    digitalWrite(in3,1);
    digitalWrite(in4,0);

   }



   else

   {
    b=-b;
    if(b>lbase)
    {
      b=lbase;
    }
    digitalWrite(in3,0);
    digitalWrite(in4,1);

   }


   analogWrite(enA,a);
   analogWrite(enB,b);
   

}






