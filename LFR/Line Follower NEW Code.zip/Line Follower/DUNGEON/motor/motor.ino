// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 160, rbase = 160;
// motor end

void setup()
{
  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end
}

void loop()
{
  motor(160, 160);
  //motor(0, 0);
  //motor(-160,-160);
  //motor(160, 0);
  //motor(-160, 0);
  //motor(0, 160);
  //motor(0, -160);
}






