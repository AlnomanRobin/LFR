void analog_read_8_array() 
{
  for (short int i=7;i>=0;i--)
  { 
    Serial.print(analogRead(i));
    Serial.print(" ");
  }  
  Serial.println();
}











