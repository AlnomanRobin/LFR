// sensor start-- 8 array
int s_8_array[8], sum_8_array ;
int base_8_array[8] = { 1, 2, 4, 8, 16, 32 , 64 , 128 };
int  sums_8_array;
// sensor end-- 8 array

void setup()
{
 // Serial monitor start
  Serial.begin(9600);
}

void loop()
{
analog_read_8_array();
}






