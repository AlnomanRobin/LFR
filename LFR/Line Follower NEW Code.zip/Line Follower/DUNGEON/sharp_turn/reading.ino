void reading_8_array() 
{
  sums_8_array = 0;
  sum_8_array = 0;
  for (byte i=7;i>=0;i--) 
  {
    s_8_array[i] = analogRead[i];
    (s_8_array[i] > threshold) ? s_8_array[i] = 1 : s_8_array[i] = 0; 
    sums_8_array = sums_8_array+(s_8_array[i] * base_8_array[i]);
    sum_8_array = sum_8_array+s_8_array[i];
  }

  Serial.print("sums= ");
  Serial.print(sums_8_array);
  Serial.print("   ");
  Serial.print("sum= ");
  Serial.println(sum_8_array);
}




