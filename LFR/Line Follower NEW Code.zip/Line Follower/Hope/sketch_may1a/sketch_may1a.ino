# include<EEPROM.h>

// motor start
# define enA 10
# define enB 11
# define in1 4
# define in2 7
# define in3 8
# define in4 12
int lbase = 200, rbase = 200;
int brake_time=50;
int turn_brake=50;
// motor end



// sensor start-- 8 array
int s_8_array[8], sum_8_array ;
int base_8_array[8] = { 1, 2, 4, 8, 16, 32 , 64 , 128 };
int  sums_8_array;
 int threshold=200;
// sensor end-- 8 array




// basic line follow start
float lsp = 20, rsp = 20, line_prop=2.5 ;
int pos=0;
// basic line follow end



float node_delay=100;



// sharp turn start
char turn='s';
uint32_t m1,m2,m3;
// sharp turn end



// T,cross,right T, left T section start
char cross='s';
char side='l'; // left hand rule or right hand rule
// T,cross,right T, left T section end





void setup()
{

  // motor start
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  // motor end

  

  // Serial monitor start
  Serial.begin(9600);
}


void analog_read_8_array() 
{
  for ( int i=7;i>=0;i--)
  { 
    s_8_array[i] = analogRead[i];
    Serial.print( s_8_array[i]);
    Serial.print(" ");
  }  
  Serial.println();
}


void digitalread_8_array() 
{
  
  sums_8_array = 0;
  sum_8_array = 0;
  for (int i=7;i>=0;i--) 
  {
    s_8_array[i] = analogRead[i];
    Serial.print(s_8_array[i]);
    if (s_8_array[i] > 150) 
    { s_8_array[i] = 1 ;}
    else
    { s_8_array[i] = 0; 
    }
    Serial.print(s_8_array[i]);
    Serial.print(" ");
  }
  Serial.println();

}





void loop()
{
   analog_read_8_array() ;
 // digitalread_8_array() ;

}
