#include "SSD1306Ascii.h"
#include "SSD1306AsciiWire.h"
#include <EEPROM.h>
SSD1306AsciiWire oled;

//for motors
byte base_L = 250, base_R = 250 , tsp = 150 ;
byte lms = 11, lmf = 6, lmb = 7, rmf = 4, rmb = 5, rms = 3;
byte up = 0, dn = 2, sw = 1, led = 13  , sound = 12;
float avg = 0, error = 0,  PID = 0;
int kp ;
int motorL, motorR;

//for sensors
int s[6], minimum[6], maximum[6] , th[6] , pos = 0  ; 
byte sensor,sum, base[6] = { 1, 2, 4, 8, 16, 32 };

//for lfr
int  stop_timer , node_delay , U_turn_delay , i_timer , T_delay , Y_cross_delay  ;
byte  brake_delay , count ;
char turn = 's', cross = 's', side = 's' , move = 's' ;
float cal_p_L , cal_p_S ;
bool i_mode = 0 ,  cont = 0 , x  ;

byte  leftTCount = 0 , rightTCount = 0 , confirmThreshold , rf ;

byte path[40], memory = 50 ;

//for timing
unsigned long t1, t2  ;



void setup()
{
Wire.begin();
Wire.setClock(400000L);
oled.begin(&Adafruit128x64, 0x3C);
oled.setFont(System5x7);
pinMode(up, INPUT_PULLUP);
pinMode(dn, INPUT_PULLUP);
pinMode(sw, INPUT_PULLUP);
pinMode(led,OUTPUT);
pinMode(sound,OUTPUT);
intro();
memory_restore();
path_load();
}

void loop() {
//  motor(base_L, base_R);
//  motor(-base_L, -base_R);
//  motor(0,0);
//  motor(base_L, 0);
//  motor(-base_L, 0);
//  motor(0, base_R);
//  motor(0, -base_R);

  byte j = push(sw);
  if (j) {
    
    byte r = menu();
    if (r) {
      memory_restore();
      path_load();
      if (r == 1) analog_display();
      if (r == 2)
      { 
        memory_restore();
        calibration();
      }
      if (r == 3)
      {  
         memory_restore();
         digital_display();
      }      
      if (r == 4)
      {
         memory_restore();
         adjustment();
      }   
      if (r == 5) {
        memory_restore();
        oled.clear();
        oled.set2X();
        text("  Ready?  ", 4, 3, 0);
        delay(1000);
        motor(base_L, base_R); 
        while (!push(sw))
          ;
        motor(0, 0);
      }
      if (r == 6) {
        memory_restore() ;
        node_delay_check() ;
      }
      if(r == 7)
      {
        path_clear() ;
      }
    }
    intro(); 
  }



  j = push(up);
  if (j) {
    memory_restore();
    path_load();
    if (j == 1) counter();
    if (j == 2) path_display();
    intro();
  }




  j = push(dn);
  if (j) {
    byte r = lfr_select();
    if (r) {

    memory_restore();
    path_load();
    if (r == 1) 
    {
      memory_restore();
      move = 'l' ;
      cross = 's';
      turn = 's';
      side = 'l';
      basic();
    }
    if (r == 2) 
    {
      memory_restore();
      move = 'r' ;
      cross = 's';
      turn = 's';
      side = 'r';
      basic();
    } 
  /*  if (r == 3) 
    {
      memory_restore();
      move = 's' ;
      cross = 's';
      turn = 's';
      side = 'r';
      basic_n();
    }*/ 
       
  }
    intro();
  }  
}


