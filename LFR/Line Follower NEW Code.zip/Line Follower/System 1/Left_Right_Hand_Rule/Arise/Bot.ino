String lfr_option(byte a) {
  if (a == 1) return " Basic-L ";
  else if (a == 2) return " Basic-R ";
  else if (a == 3) return " BasicCO ";
}

byte lfr_select() {
  byte temp = 0, index = 1, limit = 3 ;
  oled.clear();
  oled.set1X();
  while (1) {
    if (index != temp) {
      temp = index;
      for (byte i = 1; i <= limit; i++) (i == index) ? text(lfr_option(i), 37, (i-1), 1) : text(lfr_option(i), 37,(i-1), 0);
    }
    
    byte r = push(sw);
    if (r == 2) return 0;
    if (r == 1) return index;

    r = push(up);
    if (r == 1) {
      index--;
      if (index < 1) index = limit;
    }

    r = push(dn);
    if (r == 1) {
      index++;
      if (index > limit) index = 1;
    }
  }
}
