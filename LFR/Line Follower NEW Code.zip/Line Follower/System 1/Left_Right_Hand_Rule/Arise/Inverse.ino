void inverse_line() {
  bool got = 0;
  if (s[0] && s[5]) {
    t1 = millis();
    while (s[0] && s[5] && sum < 6) {
      reading(1);
      motor(base_L, base_R);
      if (millis() - t1 > i_timer) {
        got = 1;
        i_mode = !i_mode;
        oled.invertDisplay(i_mode);  
         if (path[count] == 8) 
         {
          count++;  
          cont = 0 ;
          text(String(count+1), 10, 6, 0) ;
         } 
        break;
      }
    }
    
    if (!got && sum < 6) {
        motor(base_L, base_R);
        while(s[0] || s[5]) reading(1);
        t1 = millis();
        while (millis() - t1 < 30 )  reading(1);



        if(sum == 0)
        {
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        motor(base_L, base_R);
        cross = 's';
        turn = 's';
     //   x = 0 ;
        pos = 0 ;
        digitalWrite(led,0);
        digitalWrite(sound,0);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
        }




        else if(sum > 0 && sum < 6)
        {
          t1 = millis();
          while (millis() - t1 < Y_cross_delay )  reading(1);
          cross = side;
          digitalWrite(sound, 1);
          brake(brake_delay);
          (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
          while (s[1] || s[2] || s[3] || s[4]) reading(1);
          delay(1);
          while (!s[2] && !s[3]) reading(1);
          cross = 's';
          turn = 's';
       //   x = 0 ;
          pos = 0 ;
          digitalWrite(led, 0); 
          digitalWrite(sound, 0); 
          motor(base_L, base_R);
          delay(10);
          t1 = millis();
          while(millis() - t1 < 10) mixed_4() ;
        }
     }
   }
}



