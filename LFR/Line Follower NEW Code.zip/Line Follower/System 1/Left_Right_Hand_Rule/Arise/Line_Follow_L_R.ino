void basic() {
oled.clear();
oled.set2X();
if(side=='l')  text(" Basic-L ", 10, 3, 0) ;
else if (side=='r')  text(" Basic-R ", 10, 3, 0) ;




count = EEPROM.read(19);
cont = 0;
motor(base_L, base_R);






while (1) {   start: reading(1); 
     



     if (path[count] == 10) {
      cont = 1;
      count++;
      text(String(count+1), 10, 6, 0) ;
    }






    if (sum == 0) {



      if (turn != 's') {

        if (path[count] == 11) 
              {
                count++;
                text(String(count+1), 10, 6, 0) ;
              }  
              if (path[count] == 12) {
              count++;
              text(String(count+1), 10, 6, 0) ;
              turn = 's';
              goto start;
              }

        if(x == 0  )
        {
          motor(base_L, base_R);
          delay(node_delay);
        }

        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
        cross = 's';
        pos = 0 ;
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      //  x = 0 ;


      }











      else if (abs(error) < 2) {

        t1 = millis();
        motor(base_L, base_R);
        bool gap = 1;
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {

        digitalWrite(led, 1); 
        gap = 0;
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
      //  x = 0 ;
        cross = 's';
        pos = 0 ;
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
        if (path[count] == 6) {
              count++;
              text(String(count+1), 10, 6, 0) ;
              cont = 0;
            }
          }
        if (gap && path[count] == 7) {
          count++;
          text(String(count+1), 10, 6, 0) ;
          cont = 0;
         }

        }

      }



    }
     












    else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ?  motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        turn =  's';
      //  x = 0 ;
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
      mixed();
      inverse_line();
    }















        else if (sum >= 3 && sum <= 5) {

        motor(base_L, base_R);  



        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
        








        if( (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) || (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) )  {
        leftTCount = 0 ;
        rightTCount = 0 ;
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) leftTCount++;
        else if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) rightTCount++;
        delayMicroseconds(20);
        }
        } 






        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (leftTCount == confirmThreshold)) {

          

           turn = 'l' ;
           x = 0 ;


           if((path[count] == 1 || path[count] == 2 || (cont && side == 'l'))) {


           while (!s[0] && s[5] && (sum >=1 && sum <= 5)) 
           {
            motor(base_L, base_R);
            reading(1);
           }


           delay(10); 

           if (!s[5] && (sum >=1 && sum <= 5)) {

            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            x = 1 ;
            if ((sum > 0 && sum < 6)) {






             if (path[count] == 1 || (cont && side == 'l'))   
             {
              cross = side = 'l';
              if (path[count] == 1) count++;
              text(String(count+1), 10, 6, 0) ;
             }



             if(path[count] == 2) 
             {
             cross = 's' ;
             count++;
             text(String(count+1), 10, 6, 0) ;
             }




            // cross =  side ;













             turn = 's' ;  
            // x = 0 ;         
             digitalWrite(led, 1);
            }
          }








           // else if ( sum == 0 ) 
           // {
              
           //   delay( node_delay ) ;
           //  }  
            }

         //   if((turn == side) && cont == 0)   delay( node_delay ) ;
          
      }
     








          if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (rightTCount == confirmThreshold))  {

            
            turn = 'r';
            x = 0 ;




            if((path[count] == 3 || path[count] == 2 || (cont && side == 'r'))) {


            while (s[0] && !s[5] && (sum >=1 && sum <= 5)) 
            {   
            motor(base_L, base_R);
            reading(1);
            }
            delay(10);
            if (!s[0] && (sum >=1 && sum <= 5)) {     
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
            x = 1 ;
            if ((sum > 0 && sum < 6  )) {








            if (path[count] == 3 || (cont && side == 'r'))   
            {
              cross = side = 'r';
              if (path[count] == 3) count++;
              text(String(count+1), 10, 6, 0) ;
            }  





            if(path[count] == 2) 
            {
            cross = 's' ;
            count++;
            text(String(count+1), 10, 6, 0) ;
            }


            //  cross  = side ;









              turn = 's';
            //  x = 0 ;
              digitalWrite(led, 1);
            }
          }
          //   else if ( sum == 0 ) 
          //  {
              
          //    delay( node_delay ) ;
          //   } 
         
     }

    // if((turn == side) && cont == 0)   delay( node_delay ) ;

  }

      inverse_line();
      t2 = millis();
 }
     
     










     else if ( sum == 6 ) {
      reading(1);
      if(sum == 6)  {





      turn = side ;
      x = 0 ;




      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (1) motor(0,0) ;
        }
      }





      delay(T_delay) ;
      reading(1);
    
      x = 1 ;



      if (sum > 0 && sum < 6) {

        if (cont) cross = side;

        if (path[count] == 5) {
          cont = 0;
          if(path[count + 1] == 1)  cross = side = 'l' ; 
          if(path[count + 1] == 3)  cross = side = 'r' ;
          if(path[count + 1] == 2)  cross = 's' ;
          count += 2;
          text(String(count+1), 10, 6, 0) ;
        }
        digitalWrite(sound, 1);
        turn = 's';
        //x = 0 ;
      }



      else if( sum == 0 ) {
          cross = 's' ;
          digitalWrite(led, 0);
          digitalWrite(sound, 0);
          if (path[count] == 4) {
          cont = 0;
          (path[count + 1] == 1) ? turn = side = 'l' : turn = side = 'r';
          count += 2;
          text(String(count+1), 10, 6, 0) ;
          digitalWrite(led, 1);
        }
      }




      else if(path[count] == 13)
      {
         turn = 's' ;
         while(!s[5] || !s[0]) reading(1);
         while(s[5] || s[0]) reading(1);
         delay(node_delay);
         count++ ;
         text(String(count+1), 10, 6, 0) ;
         digitalWrite(led,1);
      }




   t2 = millis();
      }
 }






    else  motor(base_L, base_R);

    if (millis() - t2 >(300) ) {
      turn = 's';
      cross = 's';
     // x = 0 ;
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }



    if (path[count] == 9) {
      brake(brake_delay);
      digitalWrite(led, 1);
      while (1) motor(0,0) ;
    }



  }
}

