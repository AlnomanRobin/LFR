// 1

/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
motor(base_L, base_R);
while (1) {   start: reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn)
        {
          motor(base_L, base_R);
          t1 = millis();
          while (millis() - t1 < node_delay )  reading(1);
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? pos = 7 : pos = -7;
        turn = 's';
        cross = 's';
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(5);
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (side == 'l') ? pos = 7 : pos = -7;
        turn = 's';
        cross = 's';
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(5);
          }
        }
      }
    }
     
    else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 7 : pos = -7;
        cross = 's';
        turn =  's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(5);
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {
      delay(10);
      reading(1);
      if (sum >= 3 && sum <= 5) {
        inverse_line();
        if (cross != 's' && (sum >= 3 && sum <= 5)) {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 7 : pos = -7;
        cross = 's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(5);
      }
    
        

        if (leftTCount == confirmThreshold) {
           turn = 'l';
           if(side == 'l') {
           while (!s[0] && s[5]) reading(1);
           if (!s[0] && !s[5]) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay - minustime)  reading(1);
            if (sum) {
             turn = 's';
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
        } 
      }
     
       else if (rightTCount == confirmThreshold) {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5]) reading(1);
            if (!s[5] && !s[0]) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay - minustime)  reading(1);
            if (sum) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          } 
        } 
     } 
      t2 = millis();
   }
 }

     else if ( sum == 6 ) {
      reading(1);  
      if ( sum == 6 ) {    
      turn = side;
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (s[5] || s[0]) reading(1);
          digitalWrite(led, 0);
          motor(base_L, base_R);
          goto start ;
        }
      }

      t1 = millis();
      while (millis() - t1 < node_delay * 0.5)  reading(1);

      if (sum) {
      cross = side;
      turn = 's';
      digitalWrite(sound, 1);
      }
   }
   t2 = millis();
 }

    if (millis() - t2 >(node_delay + 60) ) {
      turn = 's';
      cross = 's';
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/
/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
motor(base_L, base_R);
while (1) {   start: reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn)
        {
          motor(base_L, base_R);
          delay(node_delay);
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? pos = 10 : pos = -10;
        turn = 's';
        cross = 's';
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(2);
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (side == 'l') ? pos = 10 : pos = -10;
        turn = 's';
        cross = 's';
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(2);
          }
        }
      }
    }
     
    else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (sum) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 10 : pos = -10;
        cross = 's';
        turn =  's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(2);
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {  
      delay(confirmThreshold); // 30 ms , kp=90
      reading(1);
      if (sum >= 3 && sum <= 5) {
        inverse_line();
        if (cross != 's' && (sum == 3)) {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (sum) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 10 : pos = -10;
        cross = 's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(2);
      }
    
      if (!s[0] && s[5] && (s[3] || s[2])) {
           turn = 'l';
           if(side == 'l') {
           while (!s[0] && s[5]) reading(1);
           if (!s[0] && !s[5]) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
            if (sum) {
             turn = 's';
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
        } 
      }
     
     else if (s[0] && !s[5] && (s[3] || s[2])) {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5]) reading(1);
            if (!s[5] && !s[0]) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
            if (sum) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          } 
        } 
     } 
      t2 = millis();
   }
 }

     else {  
      turn = side;
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (s[5] || s[0]) reading(1);
          digitalWrite(led, 0);
          motor(base_L, base_R);
          goto start ;
        }
      }

      delay(0.5*node_delay) ;
      if (sum) {
      cross = side;
      turn = 's';
      digitalWrite(sound, 1);
      }

   t2 = millis();
 }

    if (millis() - t2 >(node_delay + 60) ) {
      turn = 's';
      cross = 's';
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/


// 3


/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
motor(base_L, base_R);
while (1) {   start: reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn)
        {
          motor(base_L, base_R);
          delay(node_delay);
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? pos = 11 : pos = -11;
        turn = 's';
        cross = 's';
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delayMicroseconds(20);
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (side == 'l') ? pos = 11 : pos = -11;
        turn = 's';
        cross = 's';
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delayMicroseconds(20);
          }
        }
      }
    }
     
   else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delayMicroseconds(20);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 11 : pos = -11;
        cross = 's';
        turn =  's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delayMicroseconds(20);
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {    
        LR_T = 0 ;
        motor(base_L, base_R);
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if (sum >= 3 && sum <= 5) LR_T++;
        delayMicroseconds(20);
        }

      if (LR_T >= 0.8*confirmThreshold) {     
        inverse_line();
        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delayMicroseconds(20);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = 11 : pos = -11;
        cross = 's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delayMicroseconds(20);
      }
    
      if (!s[0] && s[5] && (s[3] || s[2])) {
           turn = 'l';
           if(side == 'l') {
           while (!s[0] && s[5]) reading(1);
           if (!s[0] && !s[5]) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            if (sum) {
             turn = 's';
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
        } 
      }
     
        else if (s[0] && !s[5] && (s[3] || s[2])) {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5]) reading(1);
            if (!s[5] && !s[0]) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            if (sum) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          } 
        } 
     } 
      t2 = millis();
   }
 }

     else if ( sum == 6 ) {
      turn = side;
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (s[5] || s[0]) reading(1);
          digitalWrite(led, 0);
          motor(base_L, base_R);
          goto start ;
        }
      }

      delay(0.7*node_delay) ;
      reading(1);

      if (sum) {
      cross = side;
      turn = 's';
      digitalWrite(sound, 1);
      }

   t2 = millis();
 }

    if (millis() - t2 >(node_delay + 60) ) {
      turn = 's';
      cross = 's';
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/


// 5


/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
while (1) {   start: reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn)
        {
          motor(base_L, base_R);
          delay(node_delay);
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? pos = rf : pos = -rf;
        turn = 's';
        cross = 's';
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 30) mixed_4() ;
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (side == 'l') ? pos = rf : pos = -rf ;
        turn = 's';
        cross = 's';
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(10);
        t1 = millis();
        while(millis() - t1 < 30) mixed_4() ;
          }
        }
      }
    }
     
    else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = rf : pos = -rf ;
        cross = 's';
        turn =  's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 30) mixed_4() ;
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {    
        LR_T = 0 ;
        motor(base_L, base_R);
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if (sum >= 3 && sum <= 5) LR_T++;
        delayMicroseconds(20);
        }

      if (LR_T >= 0.8*confirmThreshold) {     
        
        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = rf : pos = -rf ;
        cross = 's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 30) mixed_4() ;
      }
      
      motor(base_L, base_R);
      reading(1);
      if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) {
           turn = 'l';
           if(side == 'l') {
           while (!s[0] && s[5] && (sum >=2 && sum <= 5)) 
           {
            motor(base_L, base_R);
            reading(1);
           }
           delay(10); 
           if (!s[0] && !s[5] && (sum >=1 && sum <= 2)) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            if (sum > 0 && sum < 6) {
             turn = 's';
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
        } 
      }
     
        else if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5] && (sum >=2 && sum <= 5)) 
            {
            motor(base_L, base_R);
            reading(1);
            }
            delay(10);
            if (!s[5] && !s[0] && (sum >=1 && sum <= 2)) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
             if (sum > 0 && sum < 6) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          } 
        } 
     }

      inverse_line();
      t2 = millis();
   }
 }

     else if ( sum == 6 ) {
      turn = side;
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (s[5] || s[0]) reading(1);
          digitalWrite(led, 0);
          motor(base_L, base_R);
          goto start ;
        }
      }

      delay(0.7*node_delay) ;
      reading(1);

      if (sum) {
      cross = side;
      turn = 's';
      digitalWrite(sound, 1);
      }

   t2 = millis();
 }

    else  motor(base_L, base_R);

    if (millis() - t2 >(node_delay + 60) ) {
      turn = 's';
      cross = 's';
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/



//  9


/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
count = EEPROM.read(19) ;
cont = 0 ;
while (1) {   start: reading(1);

    if (path[count] == 8) {
      cont = 1;
      count++;
    }

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn && T == 0)
        {
          motor(base_L, base_R);
          delay(node_delay);
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? pos = rf : pos = -rf;
        turn = 's';
        cross = 's';
        T = 0 ;
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(5);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        bool gap = 1;
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (!s[2] && !s[3]) reading(1);
        (side == 'l') ? pos = rf : pos = -rf ;
        turn = 's';
        cross = 's';
        T = 0 ;
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(5);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
        if (path[count] == 5) {
              count++;
              cont = 0;
            }
          }
        }
        if (gap && path[count] == 6) {
          count++;
          cont = 0;
        }
      }
    }
     
    else if (sum == 1 || sum == 2) {
      T = 0 ;
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = rf : pos = -rf ;
        cross = 's';
        turn =  's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(5);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {
        T = 0 ;    
        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-base_L, base_R) : motor(base_L, -base_R);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? pos = rf : pos = -rf ;
        cross = 's';
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(5);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
      
      motor(base_L, base_R);
      reading(1);
      if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) {
           turn = 'l';
           if(side == 'l') {
           while (!s[0] && s[5] && (sum >=1 && sum <= 5)) 
           {
            motor(base_L, base_R);
            reading(1);
           }
           delay(10); 
           if (!s[0] && !s[5] && (sum >=1 && sum <= 4)) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            if (sum > 0 && sum < 6) {
             turn = 's';
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
           delay(10);
        } 
      }
     
        else if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5] && (sum >=1 && sum <= 5)) 
            {   
            motor(base_L, base_R);
            reading(1);
            }
            delay(10);
            if (!s[5] && !s[0] && (sum >=1 && sum <= 4)) {   
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
             if (sum > 0 && sum < 6) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            } 
          }
          delay(10);
        } 
     }

      inverse_line();
      t2 = millis();
 }

     else if ( sum == 6 ) {
      turn = side;
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (s[5] || s[0]) reading(1);
          digitalWrite(led, 0);
          motor(base_L, base_R);
          goto start ;
        }
      }

      delay(0.7*node_delay) ;
      reading(1);

      if (sum > 0 && sum < 6) {
        if (cont) cross = side;
        if (path[count] == 4) {
          cont = 0;
          if (path[count + 1] == 1)  cross  = 'l' ;
          else if (path[count + 1] == 9)  cross = 's' ;
          else if (path[count + 1] == 2)  cross = 'r' ;
          count += 2;
          turn = 's';
          digitalWrite(sound, 1);
        }
      }

      else if( sum == 0 ) {
        if (path[count] == 3) {
          cont = 0;
          if (path[count + 1] == 1)  turn = 'l' ;
          else if (path[count + 1] == 2)  turn  = 'r' ;
          count += 2 ;
          cross = 's' ;
          T = 1 ;
        }
      }

   t2 = millis();
 }

    else  motor(base_L, base_R);

    if (millis() - t2 >(node_delay + 60) ) {
      turn = 's';
      cross = 's';
      T = 0 ;
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/

/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
count = EEPROM.read(19) ;
while (1) {   start: reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn && T == 0)
        {
          motor(base_L, base_R);
          delay(node_delay);
        }

        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
        cross = 's';
        T = 0 ;
        pos = 0 ;
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        bool gap = 1;
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
        cross = 's';
        T = 0 ;
        pos = 0 ;
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
        if (path[count] == 5) {
              count++;
            }
          }
        }
        if (gap && path[count] == 6) {
          count++;
        }
      }
    }
     
    else if (sum == 1 || sum == 2) {
      T = 0 ;
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ?  motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        turn =  's';
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {
        motor(base_L, base_R);
        T = 0 ;   
        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
        
        if( (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) || (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) )  {
        leftTCount = 0 ;
        rightTCount = 0 ;
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) leftTCount++;
        else if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) rightTCount++;
        delayMicroseconds(20);
        }
        } 

        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (leftTCount == confirmThreshold)) {
           turn = 'l' ;
           if(side == 'l') {
           while (!s[0] && s[5] && (sum >=1 && sum <= 5)) 
           {
            motor(base_L, base_R);
            reading(1);
           }
           delay(10); 
           if (!s[5] && (sum >=1 && sum <= 5)) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            if (sum > 0 && sum < 6) {
             turn = 's' ;
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
            else if ( sum == 0 ) delay( node_delay ) ;
        } 
      }
     
          if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (rightTCount == confirmThreshold))  {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5] && (sum >=1 && sum <= 5)) 
            {   
            motor(base_L, base_R);
            reading(1);
            }
            delay(10);
            if (!s[0] && (sum >=1 && sum <= 5)) {     
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
            if (sum > 0 && sum < 6) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          }
            else if ( sum == 0 ) delay( node_delay ) ;
        } 
     }

      inverse_line();
      t2 = millis();
 }

     else if ( sum == 6 ) {
      T = 0 ;
      turn = side ;
      if (path[count] == 9)
      {
        brake(brake_delay);
        digitalWrite(led, 1);
        while(1) motor(0,0) ;
      }
      
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while(1) motor(0,0) ;
        }
      }

      delay(T_delay) ;
      reading(1);
    
      if (sum > 0 && sum < 6) {
        cross = side;
        if (path[count] == 4) {
          if (path[count + 1] == 1)  cross  = 'l' ;
          else if (path[count + 1] == 8)  cross = 's' ;
          else if (path[count + 1] == 2)  cross = 'r' ;
          count += 2;
          turn = 's';
        }
        digitalWrite(sound, 1);
      }

      else if( sum == 0 ) {
        if (path[count] == 3) {
          if (path[count + 1] == 1)  turn = 'l' ;
          else if (path[count + 1] == 2)  turn  = 'r' ;
          count += 2 ;
          cross = 's' ;
          digitalWrite(led, 0);
          digitalWrite(sound, 0);
          T = 1 ;
        }
      }

      else if(sum == 6)
      {
         motor(base_L, base_R);
         while(s[5] || s[0]) reading(1);
      }

   t2 = millis();
 }

    else  motor(base_L, base_R);

    if (millis() - t2 >(500) ) {
      turn = 's';
      cross = 's';
      T = 0 ;
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/

/*void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
count = EEPROM.read(19) ;
while (1) {   start: reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side != turn && T == 0)
        {
          motor(base_L, base_R);
          delay(node_delay);
        }

        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
        cross = 's';
        T = 0 ;
        pos = 0 ;
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }

      else if (abs(error) < 2) {
        t1 = millis();
        motor(base_L, base_R);
        bool gap = 1;
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
        cross = 's';
        T = 0 ;
        pos = 0 ;
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
        if (path[count] == 5) {
              count++;
            }
          }
        }
        if (gap && path[count] == 6) {
          count++;
        }
      }
    }
     
    else if (sum == 1 || sum == 2) {
      T = 0 ;
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ?  motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        turn =  's';
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
      mixed();
      inverse_line();
    }

    else if (sum >= 3 && sum <= 5) {
        motor(base_L, base_R);
        T = 0 ;   
        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
        
        if( (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) || (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) )  {
        leftTCount = 0 ;
        rightTCount = 0 ;
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) leftTCount++;
        else if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) rightTCount++;
        delayMicroseconds(20);
        }
        } 

        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (leftTCount == confirmThreshold)) {
           turn = 'l' ;
           if(side == 'l') {
           while (!s[0] && s[5] && (sum >=1 && sum <= 5)) 
           {
            motor(base_L, base_R);
            reading(1);
           }
           delay(10); 
           if (!s[5] && (sum >=1 && sum <= 5)) {
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
            if (sum > 0 && sum < 6) {
             turn = 's' ;
             cross =  'l';           
             digitalWrite(led, 1);
            }
          }
            else if ( sum == 0 ) delay( node_delay ) ;
        } 
      }
     
          if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (rightTCount == confirmThreshold))  {
            turn = 'r';
            if(side == 'r') {
            while (s[0] && !s[5] && (sum >=1 && sum <= 5)) 
            {   
            motor(base_L, base_R);
            reading(1);
            }
            delay(10);
            if (!s[0] && (sum >=1 && sum <= 5)) {     
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
            if (sum > 0 && sum < 6) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          }
            else if ( sum == 0 ) delay( node_delay ) ;
        } 
     }

      inverse_line();
      t2 = millis();
 }

     else if ( sum == 6 ) {
      T = 0 ;
      turn = side ;
      if (path[count] == 9)
      {
        brake(brake_delay);
        digitalWrite(led, 1);
        while(1) motor(0,0) ;
      }
      
      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while(1) motor(0,0) ;
        }
      }

      delay(T_delay) ;
      reading(1);
    
      if (sum > 0 && sum < 6) {
        cross = side;
        if (path[count] == 4) {
          if (path[count + 1] == 1)  cross  = 'l' ;
          else if (path[count + 1] == 8)  cross = 's' ;
          else if (path[count + 1] == 2)  cross = 'r' ;
          count += 2;
          turn = 's';
        }
        digitalWrite(sound, 1);
      }

      else if( sum == 0 ) {
        if (path[count] == 3) {
          if (path[count + 1] == 1)  turn = 'l' ;
          else if (path[count + 1] == 2)  turn  = 'r' ;
          count += 2 ;
          cross = 's' ;
          digitalWrite(led, 0);
          digitalWrite(sound, 0);
          T = 1 ;
        }
      }

      else if(sum == 6)
      {
         motor(base_L, base_R);
         while(s[5] || s[0]) reading(1);
      }

   t2 = millis();
 }

    else  motor(base_L, base_R);

    if (millis() - t2 >(500) ) {
      turn = 's';
      cross = 's';
      T = 0 ;
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }
  }
}
*/
