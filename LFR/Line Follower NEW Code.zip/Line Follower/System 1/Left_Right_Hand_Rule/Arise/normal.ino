void basic_n() {
oled.clear();
oled.set2X();
if(side=='l')  text(" Basic-L ", 10, 3, 0) ;
else if (side=='r')  text(" Basic-R ", 10, 3, 0) ;
else if (move=='s')  text(" BasicCO ", 10, 3, 0) ;

motor(base_L, base_R);






while (1) {   start: reading(1); 
     








    if (sum == 0) {



      if (turn != 's') {

       

        if(side != turn  )
        {
          motor(base_L, base_R);
          delay(node_delay);
        }

        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
        cross = 's';
        pos = 0 ;
        digitalWrite(led,0);
        digitalWrite(sound,0);
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
     

      }











      else if (abs(error) < 2) {

        t1 = millis();
        motor(base_L, base_R);
        bool gap = 1;
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {

        digitalWrite(led, 1); 
        gap = 0;
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        turn = 's';
      //  x = 0 ;
        cross = 's';
        pos = 0 ;
        motor(base_L, base_R);
        digitalWrite(led, 0); 
        digitalWrite(sound, 0);  
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
       

        }

      }



    }
     
    }











    else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ?  motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        turn =  's';
      //  x = 0 ;
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
      mixed();
      inverse_line();
    }















        else if (sum >= 3 && sum <= 5) {

        motor(base_L, base_R);  



        if (cross != 's' && sum == 3 ) {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (s[1] || s[2] || s[3] || s[4]) reading(1);
        delay(1);
        while (!s[2] && !s[3]) reading(1);
        cross = 's';
        pos = 0 ;
        digitalWrite(led, 0); 
        digitalWrite(sound, 0); 
        motor(base_L, base_R);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 10) mixed_4() ;
      }
        








        if( (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) || (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) )  {
        leftTCount = 0 ;
        rightTCount = 0 ;
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) leftTCount++;
        else if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5)) rightTCount++;
        delayMicroseconds(20);
        }
        } 






        reading(1);
        if (!s[0] && s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (leftTCount == confirmThreshold)) {

          

           turn = 'l' ;
          // x = 0 ;


           if(side == 'l') {


           while (!s[0] && s[5] && (sum >=1 && sum <= 5)) 
           {
            motor(base_L, base_R);
            reading(1);
           }


           delay(10); 

           if (!s[5] && (sum >=1 && sum <= 5)) {

            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay )  reading(1);
           // x = 1 ;
            if ((sum > 0 && sum < 6)) {









             



             cross =  side ;

             // cross = 's' ;














             turn = 's' ;  
            // x = 0 ;         
             digitalWrite(led, 1);
            }
          }








            else if ( sum == 0 ) 
            {
              
              delay( node_delay ) ;
            }  
            }

           
          
      }
     








          if (s[0] && !s[5] && (s[3] || s[2]) && (sum >=2 && sum <= 5) && (rightTCount == confirmThreshold))  {

            
            turn = 'r';
        




            if( side == 'r') {


            while (s[0] && !s[5] && (sum >=1 && sum <= 5)) 
            {   
            motor(base_L, base_R);
            reading(1);
            }
            delay(10);
            if (!s[0] && (sum >=1 && sum <= 5)) {     
            motor(base_L, base_R);
            t1 = millis();
            while (millis() - t1 < node_delay)  reading(1);
            x = 1 ;
            if ((sum > 0 && sum < 6  )) {














              cross  = side ;
              
              // cross = 's' ;













              turn = 's';
            //  x = 0 ;
              digitalWrite(led, 1);
            }
          }
             else if ( sum == 0 ) 
            {
              
              delay( node_delay ) ;
             } 
         
     }

    

  }

      inverse_line();
      t2 = millis();
 }
     
     










     else if ( sum == 6 ) {
      reading(1);
      if(sum == 6)  {





      turn = side ;
   




      t1 = millis();
      motor(base_L, base_R);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (1) motor(0,0) ;
        }
      }





      delay(T_delay) ;
      reading(1);
    
     



      if (sum > 0 && sum < 6) {








         cross = move;
        // cross = 's';

        







        digitalWrite(sound, 1);
        turn = 's';
        
      }



      else if( sum == 0 ) {
          cross = 's' ;
          digitalWrite(led, 0);
          digitalWrite(sound, 0);
      }




     




   t2 = millis();
      
    }

     }






    else  motor(base_L, base_R);

    if (millis() - t2 >(300) ) {
      turn = 's';
      cross = 's';
      digitalWrite(led, 0);
      digitalWrite(sound, 0);
    }



   



  }
}


























