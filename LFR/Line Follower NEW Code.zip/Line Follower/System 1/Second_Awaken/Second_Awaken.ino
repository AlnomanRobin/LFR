#include "SSD1306Ascii.h"
#include "SSD1306AsciiWire.h"
#include <EEPROM.h>
SSD1306AsciiWire oled ;

//for motors
byte base_L = 200 , base_R = 200 , tsp = 100 ;
byte lms = 11, lmf = 7, lmb = 6, rmf = 5, rmb = 4, rms = 3;
byte up = 0, dn = 2, sw = 1, led = 13 ;
float avg = 0, error = 0,  PID = 0;
int kp , pos = 0 ;
float motorL, motorR;

// sensor
#define S0 12
#define S1 8
#define S2 9
#define S3 10
#define SIG_PIN A0
int s[12], th   ; 
int sensor,sum, base[12] = { 1, 2, 4, 8, 16, 32 , 64 , 128 , 256 , 512 , 1024 , 2048 };

//for lfr
int  node_delay , U_turn_delay ;
byte  brake_delay , count ;
char turn = 's', cross = 's', side = 's';
bool i_mode = 0 , flag = 0 ;

byte path[20], memory = 100 , leftTCount = 0 , rightTCount = 0 , confirmThreshold  , T;

//for timing
unsigned long t1, t2  ;


void setup()
{
Wire.begin();
Wire.setClock(400000L);
oled.begin(&Adafruit128x64, 0x3C);
oled.setFont(System5x7);
oled.displayRemap(1);

pinMode(S0, OUTPUT);
pinMode(S1, OUTPUT);
pinMode(S2, OUTPUT);
pinMode(S3, OUTPUT);

pinMode(lmf, OUTPUT);
pinMode(lmb, OUTPUT);
pinMode(rmb, OUTPUT);
pinMode(rmf, OUTPUT);

pinMode(up, INPUT_PULLUP);
pinMode(dn, INPUT_PULLUP);
pinMode(sw, INPUT_PULLUP);
pinMode(led,OUTPUT);

intro();
memory_restore();
//Serial.begin(9600);
}


void loop()
{
  
//  motor(base_L, base_R);
//  motor(-base_L, -base_R);
//  motor(0,0);
//  motor(base_L, 0);
//  motor(-base_L, 0);
//  motor(0, base_R);
//  motor(0, -base_R);

  byte j = push(sw);
  if (j) {
    byte r = menu();
    if (r) {
      if (r == 1) analog_display();
      if (r == 2)
      {  
         memory_restore();
         digital_display();
      }      
      if (r == 3)
      {
         memory_restore();
         adjustment();
      }   
      if (r == 4) {
        memory_restore();
        oled.clear();
        oled.set2X();
        text("  Ready?  ", 4, 3, 0);
        delay(1000);
        motor(base_L, base_R); 
        while (!push(sw))
          ;
        motor(0, 0);
      }
      if (r == 5) {
        memory_restore() ;
        node_delay_check() ;
      }
      if (r == 6) {
        path_clear() ;
      }
    }
    intro(); 
  }

  j = push(up);
  if (j) {
    if (j == 1) 
    {
      memory_restore() ;
      counter();
    }  
    if (j == 2)
    {
      path_load() ;
      path_display();
    }  
    intro();
  }

  j = push(dn);
  if (j) {
    byte r = lfr_select();
    if (r) {  
    if (r == 1) 
    {
      memory_restore();
      path_load() ;
      cross = 's';
      turn = 's';
      side = 'l';
      motor(base_L, base_R);
      basic();
    }
    if (r == 2) 
    {
      memory_restore();
      path_load() ;
      cross = 's';
      turn = 's';
      side = 'r';
      motor(base_L, base_R);
      basic();
    } 
    if (r == 3) 
    {
      memory_restore();
      path_load() ;
      cross = 's';
      turn = 's';
      side = 's';
      motor(base_L, base_R);
      basic();
    }     
  }
    intro();
  }
}
