String adj_option(byte a) {
  if (a == 1)       return "Motor Speed  ";
  else if (a == 2)  return "Kp  ";
  else if (a == 3)   return "Th   ";
  else if (a == 4)  return "Node Delay  ";
  else if (a == 5)  return "U-Turn Timer  ";
  else if (a == 6)  return "Motor Brake  ";
  else if (a == 7)  return "Motor Error  "; 
  else if (a == 8)  return "confirm Th  ";
  else if (a == 9)  return "tsp   ";
  else return "                                  ";
}

void adjustment() {
  byte base = 1, peak = base + 7, temp = 0, index = 1, limit = 9;
  String value;
  oled.clear();
  oled.set1X();

  while (1) {
    if (index != temp) {
      temp = index;
      for (byte i = base; i <= peak; i++) {
        if (i == 7) value = String(EEPROM.read(i + 49) - 25);
        else if  ((i >= 4 && i <= 6)  || i == 1 || i == 9 || i == 3)  value = String(EEPROM.read(i + 49) * 10);
        // else if (i == 3) value = String((float)EEPROM.read(i + 49)/10, 1);
        else value = String(EEPROM.read(i + 49));
        (i == index) ? text(" " + adj_option(i) + value + "              ", 0, (i - base), 1) : text(" " + adj_option(i) + value + "                ", 0, (i - base), 0);
      }
    }

    byte r = push(sw);
    if (r == 1) {
      value_screen(index);
      temp = 0;
    }
    if (r == 2) return;

    r = push(up);
    if (r == 1) {
      index--;
      if (index == 0) {
        index = limit;
        peak = index ;
        base = peak - 7;
      }
      if (index < base) {
        base = index;
        peak = base + 7;
      }
    }

    r = push(dn);
    if (r == 1) {
      index++;
      if (index > limit) {
        index = 1;
        base = index;
        peak = base + 7;
      }
      if (index > peak) {
        peak = index;
        base = peak - 7;
      }
    }
  }
}

void value_screen(byte i) {
  oled.clear();
  oled.set2X();
  int val, limit, temp = 5000;
  val = EEPROM.read(i + 49);
  String value;

  if (i == 1 || i == 9) limit = 20;
  else if (i == 7) limit = 50;
  else if (i == 6) limit = 20;
  else if((i >= 2 && i <= 5) || i == 8) limit=100;
  byte u, d;

  while (1) {
   if (temp != val) {
      temp = val;
      if (i == 7) value = String(val - 25);
      else if  ((i >= 4 && i <= 6)  || i == 1 || i == 9 || i == 3) value = String(val * 10);
     // else if (i == 3) value = String((float)val/10, 1);
      else value = String(val);
      text("SET: " + value + "         ", 4, 3, 0);
    }

    u = cont_push(up, u);
    if (u) {
      val++;
      if (val > limit) val = limit;
    }

    d = cont_push(dn, d);
    if (d) {
      val--;
      if (val < 0) val = 0;
    }

    byte r = push(sw);
    if (r) {
      if (r == 1) {
        EEPROM.write(i + 49, val);
        delay(10);
        memory_restore();
        oled.clear();
        oled.set1X();
        return;
      }
    }
  }
}
