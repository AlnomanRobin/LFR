void text(String t, int x, int y, bool color) {
  oled.setInvertMode(color);
  oled.setCursor(x, y);
  oled.print(t);
}

void intro() {
  oled.set2X();
  oled.clear();
  text("  ARISE  ", 10, 3, 0);
}

void analog_display() {
  oled.clear();
  oled.set1X();
  while (!push(sw)) {
  reading(0);    
    for (byte i = 0; i < 6; i++)     
    {
      String value = "";
      if (s[11 - i] < 1000) value += " ";
      if (s[11 - i] < 100) value += " ";
      if (s[11 - i] < 10) value += " ";
      value += String(s[11 - i]) + "  " + String(s[0 + i]) + "                 ";
      text(value, 36,6-i, 0);     
    }
  }
}

void digital_display() {
  oled.clear();
  oled.set1X();
  while (!push(sw)) {
   reading(1);
   for (byte i = 0; i < 12; i++) text(String(s[11 - i]), i * 10.6, 0, 0);
   oled.set2X();
   String value = "";
   if (sensor < 1000) value += " ";
   if (sensor < 100) value += " ";
   if (sensor < 10) value += " ";
   value += String(sensor) + "  " + String(error,1) + "                      ";
   text( value, 4, 3, 0);
   value = " ";
   value += String(sum) + "  " + String(PID,1) + "                       ";
   text( value, 4, 6, 0);
  }
}
