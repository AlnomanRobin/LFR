void pid() {
    motorL = base_L + PID;
    motorR = base_R - PID;
    motor(motorL, motorR);
}

void mixed()
{
        if (sensor == 0b000001100000) {
        if (pos != 0) {
          if(pos > 0) 
          {
            motor(0,0);
            delayMicroseconds(200);
            motor(50, -50) ;
            delayMicroseconds(200);
            motor(100, -100) ;
            delayMicroseconds(200);
            motor(150, -150) ;
            delayMicroseconds(200);
            motor(200, -200) ;
          }
          else
          {
            motor(0,0);
            delayMicroseconds(200);
            motor(-50, 50) ;
            delayMicroseconds(200);
            motor(-100, 100) ;
            delayMicroseconds(200);
            motor(-150, 150) ;
            delayMicroseconds(200);
            motor(-200, 200) ;
          }
          delay(2 * abs(pos));
          pos = 0;
        }
         pid();
      }

      else if (sensor == 0b000001000000)   pid();  
      else if (sensor == 0b000000100000)   pid();         

      else if (sensor == 0b000011000000) {
        if (pos < 1) pos = 1;
        pid();
      }
      else if (sensor == 0b000000110000) {
        if (pos > -1) pos = -1;
        pid();
      }

      else if (sensor == 0b000010000000) {
        if (pos < 2) pos = 2;
        pid();
      }
      else if (sensor == 0b000000010000) {
        if (pos > -2) pos = -2;
        pid();
      }

      else if (sensor == 0b000110000000) {
        if (pos < 3) pos = 3;
        pid();
      }
      else if (sensor == 0b000000011000) {
        if (pos > -3) pos = -3;
        pid();
      }
      
      else if (sensor == 0b000100000000) {
        if (pos < 4) pos = 4;
        pid();
      }
      else if (sensor == 0b000000001000) {
        if (pos > -4) pos = -4;
        pid();
      }

      else if (sensor == 0b001100000000) {
        if (pos < 5) pos = 5;
        pid();
      }
      else if (sensor == 0b000000001100) {
        if (pos > -5) pos = -5;
        pid();
      }

      else if (sensor == 0b001000000000) {
        if (pos < 6) pos = 6;
        pid();
      }
      else if (sensor == 0b000000000100) {
        if (pos > -6) pos = -6;
        pid();
      }

      else if (sensor == 0b011000000000) {
        if (pos < 7) pos = 7;
        pid();
      }
      else if (sensor == 0b000000000110) {
        if (pos > -7) pos = -7;
        pid();
      }

      else if (sensor == 0b010000000000) {
        if (pos < 8) pos = 8;
        pid();
      }
      else if (sensor == 0b000000000010) {
        if (pos > -8) pos = -8;
        pid();
      }

      else if (sensor == 0b110000000000) {
        if (pos < 9) pos = 9;
        pid();
      }
      else if (sensor == 0b000000000011) {
        if (pos > -9) pos = -9;
        pid();
      }

      else if (sensor == 0b100000000000) {
        if (pos < 10) pos = 10;
        pid();
      }
      else if (sensor == 0b000000000001) {
        if (pos > -10) pos = -10;
        pid();
      }
}


void mixed_6()
{
    if (sensor == B001100) {
        if (pos != 0) {
          if(pos > 0) 
          {
            motor(0,0);
            delayMicroseconds(200);
            motor(50, -50) ;
            delayMicroseconds(200);
            motor(100, -100) ;
            delayMicroseconds(200);
            motor(150, -150) ;
            delayMicroseconds(200);
            motor(200, -200) ;
          }
          else
          {
            motor(0,0);
            delayMicroseconds(200);
            motor(-50, 50) ;
            delayMicroseconds(200);
            motor(-100, 100) ;
            delayMicroseconds(200);
            motor(-150, 150) ;
            delayMicroseconds(200);
            motor(-200, 200) ;
          }
          delay(2 * abs(pos));
          pos = 0;
        }
         pid();
      }

      else if (sensor == B001000)   pid();  
      else if (sensor == B000100)   pid();         

      else if (sensor == B011000) {
        if (pos < 1) pos = 1;
        pid();
      }
      else if (sensor == B000110) {
        if (pos > -1) pos = -1;
        pid();
      }

      else if (sensor == B010000) {
        if (pos < 2) pos = 2;
        pid();
      }
      else if (sensor == B000010) {
        if (pos > -2) pos = -2;
        pid();
      }

      else if (sensor == B110000) {
        if (pos < 3) pos = 3;
        pid();
      }
      else if (sensor == B000011) {
        if (pos > -3) pos = -3;
        pid();
      }
      
      else if (sensor == B100000) {
        if (pos < 4) pos = 4;
        pid();
      }
      else if (sensor == B000001) {
        if (pos > -4) pos = -4;
        pid();
      }
}
