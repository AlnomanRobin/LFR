/*void inverse_line() {
  bool got = 0;
  if (s[0] && s[11]) {
    t1 = millis();
    while (s[0] && s[11] && sum < 12) {
      reading(1);
      motor(base_L, base_R);
      if (millis() - t1 > i_timer) {
        got = 1;
        i_mode = !i_mode;
        oled.invertDisplay(i_mode);   
        break;
      }
    }
    if (!got && sum < 12) {
        motor(base_L, base_R);
        while(s[0] || s[11]) reading(1);
        t1 = millis();
        while (millis() - t1 < 30 )  reading(1);
        if(sum == 0)
        {
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[5] && !s[6]) reading(1);
        motor(base_L, base_R);
        cross = 's';
        turn = 's';
        pos = 0 ;
        digitalWrite(led,0);
        delay(10);
        t1 = millis();
        while(millis() - t1 < 20) mixed_6() ;
        }
        else if(sum > 0 && sum < 12)
        {
          t1 = millis();
          while (millis() - t1 < Y_cross_delay )  reading(1);
          cross = side;
          brake(brake_delay);
          (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
           while (s[3] || s[4] || s[5] || s[6] || s[7] || s[8]) reading(1);
          delay(1);
          while (!s[5] && !s[6]) reading(1);
          cross = 's';
          turn = 's';
          pos = 0 ;
          digitalWrite(led, 0); 
          motor(base_L, base_R);
          delay(10);
          t1 = millis();
          while(millis() - t1 < 20) mixed_6() ;
        }
     }
   }
}
*/