void memory_restore() {
 // for (byte i = 0; i < 12; i++) {
  //  minimum[i] = EEPROM.read(i) * 4;
  //  th[i] = EEPROM.read(i + 12) * 4;
  //  maximum[i] = EEPROM.read(i + 24) * 4;
 // }
  
  count = EEPROM.read(49);
  byte speed = EEPROM.read(50) * 10 ;
  int error = EEPROM.read(56) - 25;
  (error > 0) ? base_R = speed - error : base_R = speed;
  (error < 0) ? base_L = speed + error : base_L = speed;
  node_delay = EEPROM.read(53)*10;
  brake_delay = EEPROM.read(55) * 10;
  U_turn_delay = EEPROM.read(54) * 10;
  kp = EEPROM.read(51)*10;
  confirmThreshold = EEPROM.read(57);
  tsp = EEPROM.read(58)*10 ;
  th = EEPROM.read(52)*10 ;
}

void path_load() {
  for (byte i = 0; i < 20; i++) path[i] = EEPROM.read(memory + i);
}

void path_clear() {
  oled.clear();
  oled.set2X();
  text(" WARNING! ", 4, 1, 0);
  oled.set1X();
  text(" Data will be erased ", 1, 4, 0);
  text("Short Press to cancel", 1, 6, 0);
  while (1) {
    byte r = (push(sw));
    if (r) break;
    if (!digitalRead(up) && !digitalRead(dn)) {
      oled.clear();
      text("Erasing path data....", 1, 4, 0);
      delay(800);
      for (byte i = 0; i < 20; i++) {
        EEPROM.write(memory + i, 0);
        path[i] = 0;
        delay(10);
      }
      oled.clear();
      text("  Path Data erased!  ", 1, 4, 0);
      delay(1000);
      break;
    }
  }
  intro();
}
