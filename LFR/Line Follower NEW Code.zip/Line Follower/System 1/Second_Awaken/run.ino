void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
count = EEPROM.read(49) ;

while (1) {   start: reading(1);
   

     if( sum == 12 )
   {
      T = 0;
        for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if( sum == 12 ) T++ ;
        delayMicroseconds(20);
        }

    if(sum == 12 && T >= 0.6*confirmThreshold)
    {
    brake(brake_delay);
    digitalWrite(led, 1);
    while(1) motor(0,0) ;
    }
   }
     
    else if (sum == 1 || sum == 2) {

      mixed();
    }
    

    else if ( (s[0] + s[1] + s[2] != 0) && (s[9] + s[10] + s[11] != 0) &&  (s[3] + s[4] + s[5] + s[6] +s[7] + s[8] == 0 ) )
    {
      T = 0;
      for (byte i = 0; i < confirmThreshold; i++) {
        reading(1);
        if( (s[0] + s[1] + s[2] != 0) && (s[9] + s[10] + s[11] != 0) &&  (s[3] + s[4] + s[5] + s[6] +s[7] + s[8] == 0 ) )   T++ ;
        delayMicroseconds(20);
        }

        if( (s[0] + s[1] + s[2] != 0) && (s[9] + s[10] + s[11] != 0) &&  (s[3] + s[4] + s[5] + s[6] +s[7] + s[8] == 0 ) && T>= 0.6*confirmThreshold)
        {
          reading(1) ;
          motorL = base_L + PID;
          motorR = base_R - PID;
          (side=='l') ? motor(-motorL, motorR) :  motor(motorL, -motorR) ;
        }
      
    }
       
  

  }
}
