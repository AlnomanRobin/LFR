void reading(bool mode) {
  sum = 0;
  sensor = 0;
  byte PID_sensor = 0;
  for (byte i = 0; i < 12; i++) {
    delayMicroseconds(20);
    selectChannel(i);
    s[i] = analogRead(SIG_PIN);
    if (mode) {
      (s[i] > th) ? s[i] = 1 ^ i_mode : s[i] = 0 ^ i_mode;  
      sensor += s[i] * base[i];
      PID_sensor += s[i] * (i + 1);
      sum += s[i];
    }
  }
  if (sum) avg = (float)PID_sensor / sum;
  error = 6.5 - avg;
  PID = error * kp ;
}

void selectChannel(int i) {
  digitalWrite(S0, bitRead(i, 0));  
  digitalWrite(S1, bitRead(i, 1));
  digitalWrite(S2, bitRead(i, 2));
  digitalWrite(S3, bitRead(i, 3));  
}
