byte counter() {
  oled.clear();
  oled.set2X();
  int val, limit = 255, temp = 300;
  byte u, d;
  text(" COUNTER ", 10, 2, 0);
  val = EEPROM.read(19);
  String value;

  while (1) {
    if (temp != val) {
      temp = val;
      value = String(val);
      text("    " + value + "    ", 4, 5, 0);
    }

    u = cont_push(up, u);
    if (u) {
      val++;
      if (val > limit) val = limit;
    }

    d = cont_push(dn, d);
    if (d) {
      val--;
      if (val < 0) val = 0;
    }

    byte r = push(sw);
    
    if (r) {
      if (r == 1) {
        EEPROM.write(19, val);
        delay(10);
        count = val;
        oled.clear();
        oled.set1X();
        return;
      }
    }
  }
}
