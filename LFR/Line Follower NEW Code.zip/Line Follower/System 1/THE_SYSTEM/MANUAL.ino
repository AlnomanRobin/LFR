void basic() {
oled.clear();
oled.set2X();
(side=='l') ? text(" Basic-L ", 10, 3, 0):text(" Basic-R ", 10, 3, 0);
while (1) {

start: reading(1);
    
    if (sum == 0) { 
    /*  if (turn != 's') {
        if(side!=turn)
        {
          motor(10 * spl, 10 * spr);
          delay(node_delay);
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-10 * spl, 10 * spr) : motor(10 * spl, -10 * spr);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'r') ? motor(-10 * spl, 10 * spr) : motor(10 * spl, -10 * spr);
        delay(turn_brake);
        turn = 's';
        cross = 's';
        digitalWrite(sound,0);
        digitalWrite(led,0);
        motor(10 * spl, 10 * spr);
      }

      else if (abs(pos) < 3) {
        t1 = millis();
        motor(10 * spl, 10 * spr);
        while (sum == 0) {  
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1); 
        brake(brake_delay);
        (side == 'l') ? motor(-10 * spl, 10 * spr) : motor(10 * spl, -10 * spr);
        while (!s[2] && !s[3]) reading(1);
        (side == 'r') ? motor(-10 * spl, 10 * spr) : motor(10 * spl, -10 * spr);
        delay(turn_brake);
        turn = 's';
        cross = 's';
        motor(10 * spl, 10 * spr);
        digitalWrite(sound,0);
        digitalWrite(led, 0);   
          }
        }
      }
      */
    }

    else if (sum == 1 || sum == 2) {
    /*if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-10 * spl, 10 * spr) : motor(10 * spl, -10 * spr);
        while (sum) reading(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'r') ? motor(-10 * spl, 10 * spr) : motor(10 * spl, -10 * spr);
        delay(turn_brake);
        motor(0,0);
        cross = 's';
        digitalWrite(led,0);
        digitalWrite(sound,0);
        turn='s';
        motor(10 * spl, 10 * spr);
      }*/

    if (sensor == B001100) {
        if (pos!=0) {
          (pos > 0) ? motor(250, -250) : motor(-250, 250);
          delay(2 * abs(pos));
          pos = 0;
        }
        motor(10 * spl, 10 * spr);
      }

      else if (sensor == B001000) motor(9 * spl, 10 * spr);
      else if (sensor == B000100) motor(10 * spl, 9 * spr);

      else if (sensor == B011000) {
        if (pos < 1) pos = 1;
        motor((float)(9 - lineP) * spl, 10 * spr);
      }
      else if (sensor == B000110) {
        if (pos > -1) pos = -1;
        motor(10 * spl, (float)(9 - lineP) * spr);
      }

      else if (sensor == B010000) {
        if (pos < 2) pos = 2;
        motor((float)(9 - lineP * 2) * spl, 10 * spr);
      }
      else if (sensor == B000010) {
        if (pos > -2) pos = -2;
        motor(10 * spl, (float)(9 - lineP * 2) * spr);
      }

      else if (sensor == B110000) {
        if (pos < 3) pos = 3;
        motor((float)(9 - lineP * 3) * spl, 10 * spr);
      }
      else if (sensor == B000011) {
        if (pos > -3) pos = -3;
        motor(10 * spl, (float)(9 - lineP * 3) * spr);
      }

      else if (sensor == B100000) {
        if (pos < 4) pos = 4;
        motor((float)(9 - lineP * 4) * spl, 10 * spr);
      }
      else if (sensor == B000001) {
        if (pos > -4) pos = -4;
        motor(10 * spl, (float)(9 - lineP * 4) * spr);
      }
    }

      else if (sum >= 3 && sum <= 5) {
     /* inverse_line();
      if (!s[0] && s[5] && (s[3] || s[2])) {
          turn = 'l';
          if(side == 'l')
          {
          while (!s[0] && s[5]) reading(1);
          if (!s[0]) {
            motor(10 * spl, 10 * spr);
            delay(node_delay);  
            reading(1);
            if (sum) {
             turn = 's';
             cross = 'l';            
             digitalWrite(led, 1);
            }
          }
        }
      }

     else if (s[0] && !s[5] && (s[3] || s[2])) {
         turn = 'r';
         if (side == 'r')
         {
          while (s[0] && !s[5]) reading(1);
          if (!s[5]) {
            motor(10 * spl, 10 * spr);
            delay(node_delay);  
            reading(1);
            if (sum) {
              cross  = 'r';
              turn = 's';
              digitalWrite(led, 1);
            }
          }
        }   
      }
      t2 = millis();*
    }  

    else if (sum == 6)
    {
      turn = side;
      t1 = millis();
      motor(10 * spl, 10 * spr);
      while (s[5] || s[0]) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          digitalWrite(led, 1);
          while (s[5] || s[0]) reading(1);
          digitalWrite(led, 0);
          goto start;
        }
      }

      delay(node_delay);  
      reading(1);
      if (sum) {
         digitalWrite(sound,1);
         cross = side;      
      }
      t2 = millis();
    }

    if (millis() - t2 >(node_delay+50) ) 
    { 
      turn = 's';
      cross = 's';
      digitalWrite(sound,0);
      digitalWrite(led,0);
    }
  }
}
