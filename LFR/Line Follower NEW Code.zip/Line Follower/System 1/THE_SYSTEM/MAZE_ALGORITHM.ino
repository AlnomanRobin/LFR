/*void algorithm() {
  int s = 0, a = 0;

  if (side == 'r') {
    while (1) {
      if (pa_th[a] == 3) pa_th[a] = 1;
      else if (pa_th[a] == 1) pa_th[a] = 3;
      else if (pa_th[a] == 5) break;
      a++;
    }
  }
  a = 0;

  while (1) {
    if (pa_th[a + 1] == 4) {
      a += 2; pa_th[s] = pa_th[s] + pa_th[a];
    }
    if (pa_th[s] == 4) {
      s--; a++; pa_th[s] = pa_th[s] + pa_th[a];
    }
    else {
      s++; a++; pa_th[s] = pa_th[a];
    }
    if (pa_th[s] == 5) break;
  }

    if (side == 'r') {
    a = 0;
    while (1) {
      if (pa_th[a] == 3) pa_th[a] = 1;
      else if (pa_th[a] == 1) pa_th[a] = 3;
      else if (pa_th[a] == 5) break;
      a++;
    }
  }

}
*/