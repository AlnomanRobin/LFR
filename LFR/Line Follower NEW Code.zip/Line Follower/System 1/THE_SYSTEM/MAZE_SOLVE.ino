/*  void maze_solving(bool mode) {
  oled.clear();
  oled.set2X();
  text("Maze Solve", 4, 3, 0);
  
  memory_restore();
  coun_ter=0;

  if (mode) {
    while (pa_th[coun_ter] != 5) {
      if (pa_th[coun_ter] == 3) pa_th[coun_ter] = 1;
      else if (pa_th[coun_ter] == 1) pa_th[coun_ter] = 3;
      coun_ter++;
    }
     coun_ter--;
  }
 
while (1) {

start:
    reading(1);
    
    if (sum == 0) {
      cross = 's';
      digitalWrite(led,0);  
      if (turn != 's') {
        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'l') ? motor(tsp, -tsp) : motor(-tsp, tsp);
        delay(turn_delay);
        motor(base_L, base_R);
      }
      turn = 's';
      digitalWrite(sound,0);
    }

    else if (sum == 1 || sum == 2) {
      turn = 's';
      digitalWrite(sound,0);
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (sum) reading(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'l') ? motor(tsp, -tsp) : motor(-tsp, tsp);
        delay(turn_delay);
        motor(base_L, base_R);
      }
      cross = 's';
      digitalWrite(led,0);
       
      reading(1);
      motorL = base_L + (int)PID;
      motorR = base_R - (int)PID;
      motor(motorL, motorR);
    }

    else if (sum >= 3 && sum <= 5) {
      // inverse_line();
      if (!s[0] && s[5] && (s[3] || s[2])) {  
          while (!s[0] && s[5]) reading(1);
          if (!s[5]) {
            motor(base_L, base_R);
            delay(node_delay);
            reading(1);
            if(pa_th[coun_ter] == 2) (mode) ? coun_ter-- : coun_ter++;
            else if (sum && pa_th[coun_ter]==1) {
              if (pa_th[coun_ter]==1)
            { 
              cross = 'l';
              (mode) ? coun_ter-- : coun_ter++;
              digitalWrite(led, 1);
              turn = 's';
              digitalWrite(sound, 0);
            }
          }

           else if (sum == 0) {
              turn = 'l';
              digitalWrite(sound, 1);
              cross = 's';
              digitalWrite(led, 0);
            }
          }
      }

     else if (s[0] && !s[5] && (s[3] || s[2])) {
          while (s[0] && !s[5]) reading(1);
          if (!s[0]) {
            motor(base_L, base_R);
            delay(node_delay);
            reading(1);
            if(pa_th[coun_ter] == 2) (mode) ? coun_ter-- : coun_ter++;
            else if (sum && pa_th[coun_ter] == 3) {
              if (pa_th[coun_ter] == 3) 
              {
              cross = 'r';
              (mode) ? coun_ter-- : coun_ter++;
              digitalWrite(led, 1);
              turn = 's';
              digitalWrite(sound, 0);
              }
            }

            else if (sum==0) {
              turn = 'r';
              digitalWrite(sound, 1);
              cross = 's';
              digitalWrite(led, 0);
            }
          }
      }
    }

    else {  
      t1 = millis();
      motor(base_L,base_R);
      while (sum == 6) {
        reading(1);
        if ((millis() - t1 > stop_timer) && pa_th[coun_ter]==5) {
          motor(0, 0);
          digitalWrite(led,1);
          while (s[0] || s[5]) reading(1);
          digitalWrite(led,0);
          goto start;
        }
      }
      
      delay(node_delay);
      reading(1);
      if (sum) {
          if(pa_th[coun_ter] == 2) (mode) ? coun_ter-- : coun_ter++;
          else if((pa_th[coun_ter] == 3 || pa_th[coun_ter] == 1 ))
        {
          (pa_th[coun_ter] == 1) ? cross =  'l' : cross =  'r';
          (mode) ? coun_ter-- : coun_ter++;
          digitalWrite(led, 1); 
          turn='s';
          digitalWrite(sound, 0);
        }
      }
      
      else if (sum==0 && (pa_th[coun_ter] == 3 || pa_th[coun_ter] == 1 )) {
          (pa_th[coun_ter] == 1) ? turn =  'l' : turn =  'r';
          (mode) ? coun_ter-- : coun_ter++;
          digitalWrite(sound, 1); 
          cross='s';
          digitalWrite(led, 0);
      }
    }
  }
}
*/