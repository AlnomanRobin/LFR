/*  void maze(bool mode) {
  oled.clear();
  oled.set2X();
  text("   PID.   ", 4, 3, 0);

while (1) {

    start:
    reading(1);

    if (sum == 0) {
      cross='s';
      if (turn != 's') { 
        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        delay(turn_delay);
        motor(base_L, base_R);
      }

      else if (abs(error) < 2) {
        t1 = millis();
        while (sum == 0) {
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        motor(base_L, base_R);  
        digitalWrite(led, 1);   
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        (side == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        delay(turn_delay);
        pa_th[coun_ter] = 4;
        coun_ter++;
        turn = 's';
        digitalWrite(led, 0);
        motor(base_L, base_R);
          }
        }
      }
      turn = 's';
    }

    else if (sum == 1 || sum == 2) {
      turn = 's';
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (sum) reading(1);  // while (s[2]+s[3]) reading(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        delay(turn_delay);
        motor(base_L, base_R);
      }
      cross = 's';

    reading(1);
    motorL = base_L + (int)PID;
    motorR = base_R - (int)PID;
    motor(motorL, motorR); 
    }

    else if (sum >= 3 && sum <= 5) {
      // inverse_line();
      if (!s[0] && s[5] && (s[3] || s[2])) { 
          while (!s[0] && s[5]) reading(1);
          if (!s[5]) {
            motor(base_L, base_R);
            delay(node_delay);
            reading(1);
            if (sum) {
            if (side == 'l')  cross = 'l';
              turn = 's';
              (side == 'l') ? pa_th[coun_ter] = 1 : pa_th[coun_ter] = 2;
              coun_ter++;
              digitalWrite(led, 1);
            }
            else if(sum==0)
            {
              turn = 'l';
              cross = 's';
            }
          }  
      }

     else if (s[0] && !s[5] && (s[3] || s[2])) { 
          while (s[0] && !s[5]) reading(1);
          if (!s[0]) {
            motor(base_L, base_R);
            delay(node_delay);
            reading(1);
            if (sum) {
             if (side == 'r') cross = 'r';
             turn = 's';
             (side == 'r') ? pa_th[coun_ter] = 3 : pa_th[coun_ter] = 2;
             coun_ter++;
             digitalWrite(led, 1);
            }

            else if(sum==0)
            {
              turn = 'r';
              cross='s';
            }
          }
      }
    }

    else {  
      t1 = millis();
      motor(base_L, base_R);
      while (sum == 6) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          motor(0, 0);
          pa_th[coun_ter] = 5; 
          algorithm();
          for (byte i = 0;; i++) {
            EEPROM.write(i + 200, pa_th[i]); delay(10);
            if (pa_th[i] == 5) break;
          }
          if(mode)
          {
            rotate_backward();
            maze_solving(1);
          }
          return;
        }
      }
     
      delay(node_delay);
      reading(1);
      if (sum) {
        cross = side;  // cross='s';
        turn='s';
        (side == 'l') ? pa_th[coun_ter] = 1 : pa_th[coun_ter] = 3;
        coun_ter++;
        digitalWrite(led, 1);
      }
      
      else if(sum==0)
      {
      turn = side;
      cross='s';
      (side == 'l') ? pa_th[coun_ter] = 1 : pa_th[coun_ter] = 3;
      coun_ter++;
      digitalWrite(led, 1);
      }
      t2 = millis();
    }
  }
}
*/