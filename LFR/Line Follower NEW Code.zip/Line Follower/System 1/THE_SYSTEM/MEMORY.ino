void memory_restore() {
  for (byte i = 0; i < 6; i++) {
    minimum[i] = EEPROM.read(i) * 4;
    th[i] = EEPROM.read(i + 6) * 4;
    maximum[i] = EEPROM.read(i + 12) * 4;
  }

  count = EEPROM.read(19);
  byte speed = EEPROM.read(20);
  int error = EEPROM.read(28) - 25;
  (error > 0) ? spr = speed - error : spr = speed;
  (error < 0) ? spl = speed + error : spl = speed;
  node_delay = EEPROM.read(23)*10;
  brake_delay = EEPROM.read(26) * 10;
  stop_timer = EEPROM.read(24) * 10;
  U_turn_delay = EEPROM.read(25) * 10;
  cal_p = (float)EEPROM.read(22) / 10;
  lineP = (float)EEPROM.read(21) / 10;
  i_timer = EEPROM.read(27)*10;
}

void path_load() {
  for (byte i = 0; i < 50; i++) path[i] = EEPROM.read(memory + i);
}

void path_clear() {
  oled.clear();
  oled.set2X();
  text(" WARNING! ", 4, 1, 0);
  oled.set1X();
  text(" Data will be erased ", 1, 4, 0);
  text("Short Press to cancel", 1, 6, 0);
  while (1) {
    byte r = (push(sw));
    if (r) break;
    if (!digitalRead(up) && !digitalRead(dn)) {
      oled.clear();
      text("Erasing path data....", 1, 4, 0);
      delay(800);
      for (byte i = 0; i < 50; i++) {
        EEPROM.write(memory + i, 0);
        path[i] = 0;
        delay(10);
      }
      oled.clear();
      text("  Path Data erased!  ", 1, 4, 0);
      delay(1000);
      break;
    }
  }
  intro();
}
