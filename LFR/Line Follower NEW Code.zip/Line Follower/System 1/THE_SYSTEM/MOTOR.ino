void motor(int a, int b) {
  digitalWrite(lmf, (a > 0));
  digitalWrite(lmb, (a < 0));
  digitalWrite(rmf, (b > 0));
  digitalWrite(rmb, (b < 0));
  analogWrite(lms, min(abs(a), 255));
  analogWrite(rms, min(abs(b), 255));
}



void node_delay_check()
{
  motor(10 * spl, 10 * spr);
  delay(node_delay);
  brake(brake_delay);
}
