 /*void pid_follow() {
  oled.clear();
  oled.set2X();
  (side=='l')? text("  PID--L  ", 4, 3, 0):text("  PID--R  ", 4, 3, 0);
  motor(base_L, base_R);
  delay(stop_timer/2);
  
  while (1) {

    start:
    reading(1);

    if (sum == 0) { 
      if (turn != 's') {
        if(side!=turn)
        {
          motor(base_L, base_R);
          delay(node_delay);  
        }
        brake(brake_delay);
        (turn == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        (turn == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        delay(turn_delay);
        motor(base_L, base_R);
        turn = 's';
      }

        else if (abs(error) < 2) {
        t1 = millis();
        while (sum == 0) {
        motor(base_L, base_R);  
        reading(1);
        if (millis() - t1 > U_turn_delay) {
        digitalWrite(led, 1);  
        brake(brake_delay);
        (side == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (!s[2] && !s[3]) reading(1);
        (side == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        delay(turn_delay);
        digitalWrite(led, 0);
        motor(base_L, base_R);
          }
        }
      }
    }

    else if (sum == 1 || sum == 2) {
      if (cross != 's') {
        brake(brake_delay);
        (cross == 'l') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        while (sum) reading(1);
        while (!s[2] && !s[3]) reading(1);
        (cross == 'r') ? motor(-tsp, tsp) : motor(tsp, -tsp);
        delay(turn_delay);
        digitalWrite(led,0);
        motor(base_L, base_R);
        cross = 's';
      }

      pid();
    }

    else if (sum >= 3 && sum <= 5) {
      // inverse_line();
      if (!s[0] && s[5] && (s[3] || s[2])) {
        turn = 'l';
        if (side == 'l') {
          while (!s[0] && s[5]) reading(1);
          if (!s[5]) {
            motor(base_L, base_R);
            delay(node_delay);
            reading(1);
            if (sum) {
              cross = 'l';
              digitalWrite(led, 1);
            }
          }
        }
      }

      if (s[0] && !s[5] && (s[3] || s[2])) {
        turn = 'r';
        if (side == 'r') {
          while (s[0] && !s[5]) reading(1);
          if (!s[0]) {
            motor(base_L, base_R);
            delay(node_delay);
            reading(1);
            if (sum) {
              cross = 'r';
              digitalWrite(led, 1);
            }
          }
        }
      }
      t2 = millis();
    }

    else {
      motor(base_L, base_R);  
      turn = side;
      t1 = millis();
      while (sum == 6) {
        reading(1);
        if (millis() - t1 > stop_timer) {
          brake(brake_delay);
          while (s[0] || s[5]) reading(1);
          goto start;
        }
      }
      
      delay(node_delay);
      reading(1);
      if (sum) {
      cross = side;
      digitalWrite(led, 1);
      }
      t2 = millis();
    }

    if (millis() - t2 >(node_delay+50) ) turn = 's';
  }
}
*/