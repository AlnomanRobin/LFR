

//for motors
byte spl , spr ;
byte lms = 11, lmf = 7, lmb = 6, rmf = 4, rmb = 5, rms = 3;

bool sound = 12;

//for sensors
int , 
byte sensor, 
int th[6] ;
byte sum;

//for lfr
 , node_delay , U_turn_delay ;
byte  count, brake_delay  , i_timer;
char turn = 's', cross = 's', side = 's';
float cal_p , lineP;
byte path[50], memory = 50;
bool cont = 0, i_mode = 0 , flag=0;

//for timing
 , t2;

void setup() {

}

