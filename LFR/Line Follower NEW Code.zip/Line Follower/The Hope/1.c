#include<stdio.h>

int main()

{
    int a;

    a=1000;

    printf("Value of a is %d\n",a);

    a=-21000;

    printf("Value of a is %d\n",a);


     a=10000000;

    printf("Value of a is %d\n",a);


     a=-10000000;

    printf("Value of a is %d\n",a);


     a=2147483648;

    printf("Value of a is %d\n",a);


     a=-2147483649;

    printf("Value of a is %d\n",a);



    return 0;











}
