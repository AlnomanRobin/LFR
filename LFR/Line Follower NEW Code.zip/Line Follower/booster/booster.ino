void setup() {
  // Set pin 9 as output
  pinMode(9, OUTPUT);

  // Configure Timer1 for 38kHz PWM on pin 9
  // 16 MHz / (1 * (419 + 1)) = ~38kHz
  TCCR1A = _BV(COM1A1) | _BV(WGM11);           // non-inverting, mode 14 (fast PWM)
  TCCR1B = _BV(WGM13) | _BV(WGM12) | _BV(CS10); // no prescaler
  ICR1 = 419;                                   // TOP value for 38kHz
  OCR1A = 210;                                  // 50% duty cycle
}

void loop() {
  // nothing needed here
}
