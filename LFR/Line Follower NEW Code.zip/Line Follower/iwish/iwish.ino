void setup()
{
  pinMode(12,OUTPUT);
  pinMode(13,OUTPUT);
  digitalWrite(12,HIGH);
  digitalWrite(13,HIGH);
  digitalWrite(3,LOW);
  digitalWrite(6,LOW);

}

void loop()
{
    




}