int lsp = 19, rsp =19 , line_prop=3 ;  // perfect

int reverse_force_delay=0; //  perfect   ---   shaking correction , value=3,4,4.5,5----voltage==7.9++

int node_delay=480; //  perfect --  Line Follow

int end_start_delay=630;  // perfect

int u_turn_delay=480 ;  // 710 for Line_Follow_2

int turn_brake=30;  //   perfect --- motor


void setup()
{
  


}