// Motor driver parameters
#define inA 4
#define inB 5
#define inC 6
#define inD 7
#define enA 3
#define enB 9

// IR Sensor Pin Definitions
#define IR_SENSOR_1 A0
#define IR_SENSOR_2 A1
#define IR_SENSOR_3 A2
#define IR_SENSOR_4 A3
#define IR_SENSOR_5 A4

// Sensor weights
int sensorWeight[5] = { 2, 1, 0, -1, -2 };

// Variables
int sensorValues[5];  // To store IR sensor readings
int error = 0;
int previousError = 0;
int D = 0;  // Derivative of error
int baseSpeed = 70;  // Base speed for motors
int maxTurnSpeed = 25;  // Maximum speed difference for extreme turning

// New variables for counting consecutive 00000 readings
int consecutiveZeroCount = 0;
bool motorRunning = true;  // Motor status flag

// Function to check if all sensors read 1
bool allSensorsActive() {
  for (int i = 0; i < 5; i++) {
    if (sensorValues[i] != 1) {
      return false;
    }
  }
  return true;
}

// Function to check if all sensors read 0
bool allSensorsInactive() {
  for (int i = 0; i < 5; i++) {
    if (sensorValues[i] != 0) {
      return false;
    }
  }
  return true;
}

// Function to check if all sensors except specified ones are inactive
bool allOtherSensorsInactive(int sensorA, int sensorB) {
  for (int i = 0; i < 5; i++) {
    if (i != sensorA && i != sensorB && sensorValues[i] == 1) {
      return false;  // Found an active sensor that is not sensorA or sensorB
    }
  }
  return true;  // All other sensors are inactive
}

// Function to read sensors and compute error
int calculateError() {
  error = 0;

  // Read sensor values
  sensorValues[0] = digitalRead(IR_SENSOR_1);
  sensorValues[1] = digitalRead(IR_SENSOR_2);
  sensorValues[2] = digitalRead(IR_SENSOR_3);
  sensorValues[3] = digitalRead(IR_SENSOR_4);
  sensorValues[4] = digitalRead(IR_SENSOR_5);

  // Check if all sensors are active (i.e., all values are 1)
  if (allSensorsActive()) {
    Serial.println("All sensors active. Doubling previous error for recovery.");
    D = 2 * previousError;  // Calculate derivative (D) based on doubled previous error
    return previousError;  // Keep previous error unchanged
  }

  // Check if all sensors are inactive (i.e., all values are 0)
  if (allSensorsInactive()) {
    consecutiveZeroCount++;
    Serial.print("Consecutive Zeros: ");
    Serial.println(consecutiveZeroCount);

    // Move straight when all sensors are inactive (00000)
    error = 0;  // Set error to 0 to move straight
    D = 0;      // Derivative is also 0 when moving straight

    // If 5 consecutive zeros, stop the motor
    if (consecutiveZeroCount == 5) {
      motorRunning = false;
      return 0;
    }
  } else {
    // Reset the zero counter if any other reading occurs
    if (consecutiveZeroCount >= 3 && (sensorValues[0] == 1 || sensorValues[4] == 1 || sensorValues[2] == 1)) {
      motorRunning = true;  // Continue running if pattern is like 10000, 00100, etc.
    }
    consecutiveZeroCount = 0;
  }

  // Calculate weighted error based on sensor readings
  for (int i = 0; i < 5; i++) {
    if (sensorValues[i] == 1) {
      error += sensorWeight[i];  // Accumulate error using weights
    }
  }

  // Calculate the derivative of error (D)
  D = error + previousError;
  previousError = error;  // Update the previous error for the next loop

  // Serial output for debugging sensor readings, error, and derivative
  Serial.print("Sensor Values: ");
  for (int i = 0; i < 5; i++) {
    Serial.print(sensorValues[i]);
    Serial.print(" ");
  }
  Serial.print("| Error: ");
  Serial.print(error);
  Serial.print(" | Derivative (D): ");
  Serial.println(D);

  return error;
}

// Function to run motors
void runMotors(int leftSpeed, int rightSpeed) {
  if (!motorRunning) {
    leftSpeed = 0;
    rightSpeed = 0;
  }

  // Set motor directions based on speed sign
  if (leftSpeed > 0) {
    digitalWrite(inA, HIGH);
    digitalWrite(inB, LOW);
  } else {
    digitalWrite(inA, LOW);
    digitalWrite(inB, HIGH);
  }

  if (rightSpeed > 0) {
    digitalWrite(inC, HIGH);
    digitalWrite(inD, LOW);
  } else {
    digitalWrite(inC, LOW);
    digitalWrite(inD, HIGH);
  }

  // Set motor speeds
  analogWrite(enA, abs(leftSpeed));  // Left motor speed
  analogWrite(enB, abs(rightSpeed));  // Right motor speed
}

// Function to determine speed for turns based on error value
int determineSpeedForError(int absD) {
  if (absD == 1) {
    return baseSpeed - (maxTurnSpeed * 2 / 6);
  } else if (absD == 2) {
    return baseSpeed - (2 * maxTurnSpeed * 3 / 6);
  } else if (absD == 3) {
    return baseSpeed - (3 * maxTurnSpeed * 4 / 6);
  } else if (absD == 4) {
    return baseSpeed - (4 * maxTurnSpeed * 4.5 / 6);
  } else if (absD == 5) {
    return baseSpeed - (5 * maxTurnSpeed * 5 / 6);
  } else if (absD == 6) {
    return baseSpeed - maxTurnSpeed * 5.5;  // Maximum speed reduction
  }
  return baseSpeed;
}

// Function to turn right based on the value of D
void turnRight(int D) {
  int speedAdjustment = determineSpeedForError(abs(D));  // Determine speed adjustment based on D
  int rightSpeed = speedAdjustment;  // Right motor slows down
  int leftSpeed = baseSpeed;  // Left motor runs at base speed

  // Run the motors with the calculated speed
  runMotors(leftSpeed, rightSpeed);
  Serial.print("Turning Right with D: ");
  Serial.println(D);
}

// Function to turn left based on the value of D
void turnLeft(int D) {
  int speedAdjustment = determineSpeedForError(abs(D));  // Determine speed adjustment based on D
  int leftSpeed = speedAdjustment;  // Left motor slows down
  int rightSpeed = baseSpeed;  // Right motor runs at base speed

  // Run the motors with the calculated speed
  runMotors(leftSpeed, rightSpeed);
  Serial.print("Turning Left with D: ");
  Serial.println(D);
}

// Function to set up motor pins and sensors
void setup() {
  // Initialize serial communication
  Serial.begin(9600);

  // Set motor pins as outputs
  pinMode(inA, OUTPUT);
  pinMode(inB, OUTPUT);
  pinMode(inC, OUTPUT);
  pinMode(inD, OUTPUT);
  pinMode(enA, OUTPUT);
  pinMode(enB, OUTPUT);

  // Set IR sensor pins as inputs
  pinMode(IR_SENSOR_1, INPUT);
  pinMode(IR_SENSOR_2, INPUT);
  pinMode(IR_SENSOR_3, INPUT);
  pinMode(IR_SENSOR_4, INPUT);
  pinMode(IR_SENSOR_5, INPUT);
}

// Main loop
void loop() {
  // Call the function to calculate error and derivative
  calculateError();

  // If motor should stop due to 5 consecutive 00000 readings
  if (!motorRunning) {
    Serial.println("Motor stopped due to 5 consecutive zeros.");
    runMotors(0, 0);  // Stop the motor
    return;  // Exit the loop early
  }

  // Motor control logic based on the value of D
  if (D > 0) {
    // Turn right if D is positive
    turnRight(D);  // Call the turnRight function
  } else if (D < 0) {
    // Turn left if D is negative
    turnLeft(D);  // Call the turnLeft function
  } else {
    // Move straight if D is 0
    Serial.println("Moving Straight");
    runMotors(baseSpeed, baseSpeed);  // Both motors at base speed
  }